// This is a program calculate a model system about the Helium atoms.
// Many methods are provided for the statistic properties.
// This program can change the method by a series of keys,
// which have the default values.
// This program has the deep dividing, for the different function.
// Less define, more variables
// date: 2020/11/14


#include "define.h"

#include "file.h"
#include "unit.h"
#include "lib.h"
#include "ensemble.h"
#include "particle.h"
#include "verlet.h"
#include "info.h"
#include "pot.h"
#include "mc.h"
#include "md.h"
#include "hmc.h"

//################################# global define #################################




//################################# object & functions #################################
// packaging the special objects & the functions of the objects

//-------- The time object --------
#ifdef WIN_CONDITION

#else
static void displayProcessTimes(const char* msg)
{
	struct tms t;
	clock_t clockTime;
	static long clockTicks = 0;

	if (msg != NULL)
		printf("%s ", msg);
	if (clockTicks == 0)
	{
		clockTicks = sysconf(_SC_CLK_TCK);
		if (clockTicks == -1)
			perror("sysconf");
	}
	clockTime = clock();
	if (clockTime == -1)
		perror("clock");
	printf("      clock() returns: %ld clocks-per-sec (%.2f secs)\n", \
		(long)clockTime, (double)clockTime / CLOCKS_PER_SEC);
	if (times(&t) == -1)
		perror("times");
	printf("       times() yields: user CPU = %.2f; system CPU: %.2f\n", \
		(double)t.tms_utime / clockTicks, (double)t.tms_stime / clockTicks);
}
#endif //WIN_CONDITION
//-------- End of The time object --------



int hmc_cal(ParticleList* pl, Ensemble* ense, VerletList* vl, Input inputinfo, FileList fl)
{
	HMCInfo hmci;
	HMCFun hmcf;
	NHChain nhc = { .num = 0, .num_1 = 0, .chain_length = 0, .eta = NULL, .G = NULL, .peta = NULL, .Q = NULL };
	NHChain nhc_baro = { .num = 0, .num_1 = 0, .chain_length = 0, .eta = NULL, .G = NULL, .peta = NULL, .Q = NULL };
	Barostat baro;
	ParticleList* pl_tmp;
	int i, j, k, m;
	int info_step;
	double* buff[INFO_NUM];
	int buff_i[INFO_BUFF_SIZE];
	char* formstr;
	char* formdata;
	LJPotential lj;


	for (i = 0; i < INFO_NUM; i++)
		if ((buff[i] = (double*)malloc(INFO_BUFF_SIZE * sizeof(double))) == NULL)
		{
			perror("malloc_mc_buff");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}
	if ((pl_tmp = (ParticleList*)malloc(sizeof(ParticleList))) == NULL)
	{
		perror("malloc_ParticleList");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}

	init_hmc(&hmci, &hmcf, &inputinfo, ense, pl, &nhc, &nhc_baro, &baro);
	init_lj(&lj, HeLJ);
	init_particle_list_const(pl_tmp, 1, pl->num, pl->list->subnum);
	info_step = hmci.mci.mc_step_num / hmci.mci.mc_info_num;
	k = 0;
#ifdef VERLET_USE
	create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
	printf("| step num |         temperature    (K)         |            energy      (eV)          |            pressure      (kPa)      |           volume      (kg/m^3)    |\n");
	printf("|----------|------------------------------------|--------------------------------------|-------------------------------------|-----------------------------------|\n");
	formstr = "|%10d|      %-30.10f|      %-30.10f  |      %-30.10f |    %-30.10f |\n";
	formdata = "%-10d %-30.10f\n";

	for (i = 0; i < hmci.mci.mc_step_num; i += info_step)
	{
		particle_info(pl, ense, vl, 0);
		//printf("%d\n", i);
		buff_i[k] = i;
		buff[0][k] = ense->temp;
		buff[1][k] = ense->energy * unit.eV1hatree;
		buff[2][k] = ense->press[0][0] * unit.kPa1P;
		buff[3][k] = pow(ense->h[0][0] * unit.ang1bohr, 3.0);
		buff[4][k] = ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au;
		k++;
		if (k == INFO_BUFF_SIZE)
		{
			printf(formstr, buff_i[0], buff[0][0], buff[1][0], buff[2][0], buff[3][0]);
			for (m = 0; m < k; m++)
			{
				fprintf(fl.temp_fp, formdata, buff_i[m], buff[0][m]);
				fprintf(fl.energy_fp, formdata, buff_i[m], buff[1][m]);
				fprintf(fl.press_fp, formdata, buff_i[m], buff[2][m]);
				fprintf(fl.volume_fp, formdata, buff_i[m], buff[3][m]);
				fprintf(fl.density_fp, formdata, buff_i[m], buff[4][m]);
			}
			k = 0;
		}
		for (j = 0; j < info_step; j++)
		{
			//printf("%d, %d, %d, %f\n", i, j, k++, nhc.eta[0]);
			hmc_step(&hmci, &hmcf, pl, pl_tmp, ense, &baro, vl, lj, nhc, nhc_baro);
		}
		translation(pl, ense);
#ifdef VERLET_USE
		create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
	}

	particle_info(pl, ense, vl, 0);
	printf(formstr, i, ense->temp, ense->energy * unit.eV1hatree, ense->press[0][0] * unit.kPa1P, pow(ense->h[0][0] * unit.ang1bohr, 3.0));
	fprintf(fl.temp_fp, formdata, i, ense->temp);
	fprintf(fl.energy_fp, formdata, i, ense->energy * unit.eV1hatree);
	fprintf(fl.press_fp, formdata, i, ense->press[0][0] * unit.kPa1P);
	fprintf(fl.volume_fp, formdata, i, pow(ense->h[0][0] * unit.ang1bohr, 3.0));
	fprintf(fl.density_fp, formdata, i, ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au);

	for (i = 0; i < INFO_NUM; i++)
		free(buff[i]);
	free_particle_list(pl_tmp, 1);
	free(pl_tmp);
	return 0;
}



//-------- End of The Hybrid MC method --------


//################################# functions #################################
// the function in the program
// they will be divided into different files

//--------- Monte Carlo ---------

int mc_cal(ParticleList* pl, Ensemble* ense, VerletList* vl, Input inputinfo, FileList fl)
{
	// calculate a complete Monte Carlo
	int i, j, k, m;
	int info_step;
	double* buff[INFO_NUM];
	int buff_i[INFO_BUFF_SIZE];
	char* formstr;
	char* formdata;
	LJPotential lj;
	MCInfo mci;
	MCFun mcf;
	

	for (i = 0; i < INFO_NUM; i++)
		if ((buff[i] = (double*)malloc(INFO_BUFF_SIZE * sizeof(double))) == NULL)
		{
			perror("malloc_mc_buff");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}

	init_mc(&mci, &mcf, inputinfo);
	init_lj(&lj, HeLJ);
	info_step = mci.mc_step_num / mci.mc_info_num;
	k = 0;
#ifdef VERLET_USE
	create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
	printf("| step num |         temperature    (K)         |            energy      (eV)          |            pressure      (kPa)      |           volume      (kg/m^3)    |\n");
	printf("|----------|------------------------------------|--------------------------------------|-------------------------------------|-----------------------------------|\n");
	formstr = "|%10d|      %-30.10f|      %-30.10f  |      %-30.10f |    %-30.10f |\n";
	formdata = "%-10d %-30.10f\n";
	if (mcf.mc_step == NULL)
	{
		printf(" Error: wrong ensemble\n");
		return -1;
	}
	else
	{
		for (i = 0; i < mci.mc_step_num; i += info_step)
		{
			particle_info(pl, ense, vl, 0);
			buff_i[k] = i;
			buff[0][k] = ense->temp;
			buff[1][k] = ense->energy * unit.eV1hatree;
			buff[2][k] = ense->press[0][0] * unit.kPa1P;
			buff[3][k] = pow(ense->h[0][0] * unit.ang1bohr, 3.0);
			buff[4][k] = ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au;
			k++;
			if (k == INFO_BUFF_SIZE)
			{
				printf(formstr, buff_i[0], buff[0][0], buff[1][0], buff[2][0], buff[3][0]);
				for (m = 0; m < k; m++)
				{
					fprintf(fl.temp_fp, formdata, buff_i[m], buff[0][m]);
					fprintf(fl.energy_fp, formdata, buff_i[m], buff[1][m]);
					fprintf(fl.press_fp, formdata, buff_i[m], buff[2][m]);
					fprintf(fl.volume_fp, formdata, buff_i[m], buff[3][m]);
					fprintf(fl.density_fp, formdata, buff_i[m], buff[4][m]);
				}
				k = 0;
			}
			for (j = 0; j < info_step; j++)
			{
				//printf("%d, %d, %d\n", i, j, k++);
				mcf.mc_step(&mci, pl, vl, ense, lj);
			}
			translation(pl, ense);
#ifdef VERLET_USE
			create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
		}
	}
	particle_info(pl, ense, vl, 0);
	printf(formstr, i, ense->temp, ense->energy * unit.eV1hatree, ense->press[0][0] * unit.kPa1P, pow(ense->h[0][0] * unit.ang1bohr, 3.0));
	fprintf(fl.temp_fp, formdata, i, ense->temp);
	fprintf(fl.energy_fp, formdata, i, ense->energy * unit.eV1hatree);
	fprintf(fl.press_fp, formdata, i, ense->press[0][0] * unit.kPa1P);
	fprintf(fl.volume_fp, formdata, i, pow(ense->h[0][0] * unit.ang1bohr, 3.0));
	fprintf(fl.density_fp, formdata, i, ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au);

	for (i = 0; i < INFO_NUM; i++)
		free(buff[i]);

	return 0;
}


//--------- Molecular Dynamic ---------

int md_cal(ParticleList* pl, Ensemble* ense, VerletList* vl, Input inputinfo, FileList fl)
{
	// calculate a complete Molecular dynamic
	int i, j, k, m;
	int info_step;
	double* buff[INFO_NUM];
	int buff_i[INFO_BUFF_SIZE];
	char* formstr;
	char* formdata;
	LJPotential lj;
	MDInfo mdi;
	MDFun mdf;
	NHChain nhc = { .num = 0, .num_1 = 0, .chain_length = 0, .eta = NULL, .G = NULL, .peta = NULL, .Q = NULL };
	NHChain nhc_baro = { .num = 0, .num_1 = 0, .chain_length = 0, .eta = NULL, .G = NULL, .peta = NULL, .Q = NULL };
	Barostat baro;
	

	for (i = 0; i < INFO_NUM; i++)
		if ((buff[i] = (double*)malloc(INFO_BUFF_SIZE * sizeof(double))) == NULL)
		{
			perror("malloc_mc_buff");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}

	init_md(&mdi, &mdf, &inputinfo, ense, pl, &nhc, &nhc_baro, &baro);
	init_lj(&lj, HeLJ);


	//for (i = 0; i < nhc.chain_length; i++)
	//{
	//	printf(" -- %f -- \n", nhc.Q[i]);
	//}
	//system("pause");exit(EXIT_FAILURE);
	info_step = mdi.md_step_num / mdi.md_info_num;
	k = 0;
#ifdef VERLET_USE
	create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
	printf("| step num |         temperature    (K)         |            energy      (eV)          |            pressure      (kPa)      |           volume      (kg/m^3)    |\n");
	printf("|----------|------------------------------------|--------------------------------------|-------------------------------------|-----------------------------------|\n");
	formstr = "|%10d|      %-30.10f|      %-30.10f  |      %-30.10f |    %-30.10f |\n";
	formdata = "%-10f %-30.10f\n";

	if (mdf.propagator == NULL)
	{
		printf(" Error: wrong ensemble\n");
		return -1;
	}
	else
	{
		for (i = 0; i < mdi.md_step_num; i += info_step)
		{
			mdi.step = i;
			//if(mark != ENSEMBLE_NPT)
			particle_info(pl, ense, vl, 0);
			//printf("%ld \n", ense->rdf.histogram[95]);
			buff_i[k] = i;
			buff[0][k] = (double)i * inputinfo.deltaT;
			buff[1][k] = ense->temp;
			buff[2][k] = ense->energy * unit.eV1hatree;
			buff[3][k] = ense->press[0][0] * unit.kPa1P;
			buff[4][k] = pow(ense->h[0][0] * unit.ang1bohr, 3.0);
			buff[5][k] = ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au;
			k++;
//#ifdef DEBUG_
//			if (ense->press[0][0] < 0)
//				return 0;
//#endif // DEBUG_

			//for (j = 0; j < pl->num; j++)
			//	for (m = 0; m < DIM; m++)
			//		printf("%d %d %f\n", j, m, (pl->list + j)->p[m]);
			if (k == INFO_BUFF_SIZE)
			{
				printf(formstr, buff_i[0], buff[1][0], buff[2][0], buff[3][0], buff[4][0]);
#ifdef DEBUG_
				fprintf(debugfp, formstr, buff_i[0], buff[1][0], buff[2][0], buff[3][0], buff[4][0]);
				fprintf(debugfp, "%lf, %lf\n", ense->mv2, ense->virial);
#endif
				for (m = 0; m < k; m++)
				{
					fprintf(fl.temp_fp, formdata, buff[0][m], buff[1][m]);
					fprintf(fl.energy_fp, formdata, buff[0][m], buff[2][m]);
					fprintf(fl.press_fp, formdata, buff[0][m], buff[3][m]);
					fprintf(fl.volume_fp, formdata, buff[0][m], buff[4][m]);
					fprintf(fl.density_fp, formdata, buff[0][m], buff[5][m]);
				}
				k = 0;
			}
			for (j = 0; j < info_step; j++)
			{
				//printf("%d, %d, %d\n", i, j, k++);
				mdf.propagator(&mdi, pl, ense, &baro, vl, lj, nhc, nhc_baro);
			}
#ifdef DEBUG_
			distance(pl, vl);
#endif // DEBUG_

			translation(pl, ense);

#ifdef VERLET_USE
			create_verlet_list_monatomic(vl, pl, ense);
#endif // VERLET_USE
		}
	}
	particle_info(pl, ense, vl, 0);
	buff_i[k] = i;
	buff[0][k] = (double)i * inputinfo.deltaT;
	buff[1][k] = ense->temp;
	buff[2][k] = ense->energy * unit.eV1hatree;
	buff[3][k] = ense->press[0][0] * unit.kPa1P;
	buff[4][k] = pow(ense->h[0][0] * unit.ang1bohr, 3.0);
	buff[5][k] = ense->total_mass / pow(ense->h[0][0], 3.0) * unit.density1au;
	printf(formstr, buff_i[k], buff[1][k], buff[2][k], buff[3][k], buff[4][k]);
	fprintf(fl.temp_fp, formdata, buff[0][k], buff[1][k]);
	fprintf(fl.energy_fp, formdata, buff[0][k], buff[2][k]);
	fprintf(fl.press_fp, formdata, buff[0][k], buff[3][k]);
	fprintf(fl.volume_fp, formdata, buff[0][k], buff[4][k]);
	fprintf(fl.density_fp, formdata, buff[0][k], buff[5][k]);

	if(mdi.nhc_sw)
		free_nhc(&nhc);
	if(mdi.nhc_baro_sw)
		free_nhc(&nhc_baro);

	for (i = 0; i < INFO_NUM; i++)
		free(buff[i]);

	return 0;
}


//################################# main functino #################################
// the main body of the program
int main(int argc, char* argv[])
{
	ParticleList* pl;
	Ensemble* ense;
	VerletList* vl;
	Input inp;
	FileList fl;
	
	int num_par;
	int num_ens;
	int i, j; // loop index
	
#ifdef WIN_CONDITION
	time_t start_t, end_t;
	time(&start_t);
#else
	displayProcessTimes("At program start:\n");
	// pid
	printf(" The PID of the program is: %ld\n", (long)getpid());
#endif // WIN_CONDITION

	// init part

	init_file(&fl);
	num_ens = 1;
	num_par = 100;

	init_rand();
	init_unit();
	read_input_file(&inp, fl.input_fp);

#ifdef WIN_CONDITION
	full_screen();
#endif // WIN_CONDITION
#ifdef DEBUG_
	fopen_n((FILE**)&debugfp, "debuglog.txt", "w", "fopen_n_debug");
#endif

	num_ens = inp.species_num;
	num_par = inp.particle_num[0];

	
	if ((pl = (ParticleList*)malloc(num_ens * sizeof(ParticleList))) == NULL)
	{
		perror("malloc_ParticleList");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	init_particle_list_const(pl, num_ens, num_par, inp.particle_atom_num);
	if ((ense = (Ensemble*)malloc(num_ens * sizeof(Ensemble))) == NULL)
	{
		perror("malloc_ParticleList");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((vl = (VerletList*)malloc(num_ens * sizeof(VerletList))) == NULL)
	{
		perror("malloc_VerletList");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	init_ensembles_const(ense, num_ens, num_par);
	init_ense_conditon(ense, &inp);
	

	if (inp.coord_xp_output)
	{
		init_coord(pl, ense, &fl, num_ens, inp.trajectory);
		printf(" output the coord from the traj.dat file\n");
		coord_pic(pl, ense, &fl);
		exit(EXIT_SUCCESS);
	}
	else
	{
		init_coord(pl, ense, &fl, num_ens, inp.trajectory);
	}

	vl->radius = inp.truncate_r * unit.bohrlang;
	init_verlet_list(vl, pl);

	if (!(ense->rdf_switch) || (init_rdf(&ense->rdf, 100, inp.truncate_r) != 0))
		ense->rdf_switch = false;

	switch (inp.method)
	{
	case METHOD_MC:
		printf(" Monte Carlo simulation ...\n");
		mc_cal(pl, ense, vl, inp, fl);
		break;
	case METHOD_MD:
		printf(" Molecular dynamic simulation ... \n");
		md_cal(pl, ense, vl, inp, fl);
		break;
	case METHOD_HMC:
		printf(" Hybrid molecular dynamic simulation ... \n"); 
		hmc_cal(pl, ense, vl, inp, fl);
		break;
	default:
		printf(" Error: not appoint the method of the simulation\n exit the program ... \n");
		break;
	}

	if (ense->rdf_switch)
	{
		printf(" saving the RDF information ...\n");
		printf_rdf(&ense->rdf, &fl);
		free_rdf(&ense->rdf);
	}
	save_trajectory(pl, ense, &fl, num_ens);


	// free part
	free_verlet_list(vl);
	free_particle_list(pl, num_ens);
	free_ensembles(ense, num_ens);
	fclose_file(&fl);
	printf("-------------------- End of the program --------------------\n");

#ifdef WIN_CONDITION
	time(&end_t);
	printf(" time: %f (s)\n", difftime(end_t, start_t));
#else
	displayProcessTimes("At program end:\n");
#endif // WIN_CONDITION
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
	system("pause");
#else
	getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
	return 0;
}
