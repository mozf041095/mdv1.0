#include "define.h"
#include "verlet.h"
#include "lib.h"
#include "unit.h"

//-------- The Verlet List object --------

int init_verlet_list(VerletList* vl, ParticleList* pl)
{
	vl->radius2 = pow(vl->radius, 2);
	vl->numMax = pl->num ;

	if ((vl->x = (int*)malloc(pl->num * vl->numMax * 2 * sizeof(int))) == NULL)
	{
		perror("malloc_verlet_x");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((vl->num = (int*)malloc(pl->num * sizeof(int))) == NULL)
	{
		perror("malloc_verlet_num");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((vl->num_total = (int*)malloc(pl->num * sizeof(int))) == NULL)
	{
		perror("malloc_verlet_num");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}

	return 0;
}

int free_verlet_list(VerletList* vl)
{
	free(vl->x);
	free(vl->num);
	free(vl->num_total);
	return 0;
}


//#undef PERRIODIC
int create_verlet_list_monatomic(VerletList* vl, ParticleList* pl, Ensemble* ense)
{
	// create a verlet list for every particles( not atoms)
	int i, j, k, js, num, numMax, ibox, nbox;
	int x1, x2; // debug
	double r;
	double shift[BOXNUM][DIM];
	num = pl->num;
	numMax = vl->numMax;
#ifdef PERRIODIC
	nbox = BOXNUM;
#else
	nbox = 1;
#endif
	for (ibox = 0; ibox < nbox; ibox++)
	{
#ifdef PERRIODIC
		for (k = 0; k < DIM; k++)
		{
			shift[ibox][k] = (double)box_index(ibox, k) * ense->h[k][k];
			//printf("	%d : %d -- %f\n", i, box_index(ibox, i), shift[i]);
		}
		//fprintf( debugfp, "\n");
#else
		for (k = 0; k < DIM; k++)
			shift[ibox][k] = 0;
#endif // PERRIODIC
	}
	for (i = 0; i < num; i++) // particle 1
	{
		js = 0;
		for (j = i + 1; j < num; j++) // particle 2
		{
			//if (i == j) continue;
			for (ibox = 0; ibox < nbox; ibox++)
			{
				r = 0;
				for (k = 0; k < DIM; k++) // dim 1-3
					r += pow((pl->list + i)->x[k] - ( (pl->list + j)->x[k] + shift[ibox][k] ), 2.0); // shift define
#ifdef DEBUG_
				if (r * unit.ang1bohr < 1.5)
					fprintf(debugfp, "%d %d %d (%d) -- %lf", i, j, k, ibox, r);
#endif // DEBUG_

				// create the rdf dis
				//printf(" -- %d, %d, %d -- %f, %f\n", i, j, ibox, r, vl->radius2);
				//if (ense->rdf_switch && r <= ense->rdf.rmax * ense->rdf.rmax)
				//{
				//	ense->rdf.histogram[(int)(sqrt(r) / (double)ense->rdf.delta_r)]++;
				//}
				if (r < vl->radius2)
				{
					*(vl->x + i * numMax * 2 + (js++)) = j;
					*(vl->x + i * numMax * 2 + (js++)) = ibox;
					//break;
				}
			}
		}
		*(vl->num + i) = js / 2;
		//printf("%d\n", *(vl->num + i));
		for (j = 0; j < i; j++) // particle 2
		{
			//if (i == j) continue;
			for (ibox = 0; ibox < nbox; ibox++)
			{
				r = 0;
				for (k = 0; k < DIM; k++) // dim 1-3
					r += pow((pl->list + i)->x[k] - ( (pl->list + j)->x[k] + shift[ibox][k] ), 2.0); // shift define
				// create the rdf dis
				//printf(" -- %d, %d, %d -- %f, %f\n", i, j, ibox, r, vl->radius2);
				/*if (ense->rdf_switch && r <= ense->rdf.rmax * ense->rdf.rmax)
				{
					ense->rdf.histogram[(int)(sqrt(r) / (double)ense->rdf.delta_r)]++;
				}*/
#ifdef DEBUG_
				//if (r < pow(2.3 * unit.bohrlang, 2.0))
				//	fprintf(debugfp, " ----- %f ----- \n", sqrt(r) * unit.ang1bohr);
#endif // DEBUG_
				if (r < vl->radius2)
				{
					*(vl->x + i * numMax * 2 + (js++)) = j;
					*(vl->x + i * numMax * 2 + (js++)) = ibox;
					//break;
				}
			}
		}
		*(vl->num_total + i) = js / 2;
		//printf("%d %d %d\n", i, *(vl->num + i), *(vl->num_total + i));
	}
	//x1 = 0; x2 = 0;
	//for (i = 0; i < num; i++)
	//{
	//	x1 += *(vl->num + i);
	//	x2 += *(vl->num_total + i);
	//}
	//printf("%d %d\n", x1, x2);
	//exit(EXIT_SUCCESS);
	return 0;
}


void distance(ParticleList* pl, VerletList* vl)
{
	int i, j, k;
	double dis;
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			dis = 0;
			for (k = 0; k < DIM; k++)
				dis += pow((pl->list + i)->x[k] - (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k], 2.0);
			if (dis * unit.ang1bohr < 1.5)
			{
				printf(" dis: %d %d %f\n", i, *(vl->x + i * vl->numMax * 2 + j), dis);
			}
		}
	}
}
//-------- End of The Verlet List object --------


