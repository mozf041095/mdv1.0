#include "define.h"
#include "unit.h"
#include "lib.h"
#include "pot.h"



//-------- The LJ Potential object --------

int init_lj(LJPotential* lj, int mark)
{
	// init the lj potential
	switch (mark)
	{
	case HeLJ:
		// He atom
		lj->epsilon = 10.22 * unit.kb;
		lj->sigma = 2.556 * unit.bohrlang;
		break;
	default:
		break;
	}
	lj->m4_epsilon = 4.0 * lj->epsilon;
	lj->sigma_2 = pow(lj->sigma, 2.0);
}

double lj_pair_pot(double x1[], double x2[], LJPotential lj)
{
	// pair energy between x1 & x2
	double r;
	int i;
	r = 0;
	for (i = 0; i < DIM; i++)
	{
		r += pow((x1[i] - x2[i]), 2.0);
		//printf("\t\t\t\t\t%f, %f, %f\n", x1[i], x2[i], r);
	}
	//r = lj.sigma_2 / r;
	////printf("%f, %f\n", r, lj.m4_epsilon * (pow(r, 6) - pow(r, 3)));
	//return lj.m4_epsilon * (pow(r, 6) - pow(r, 3));
	r = pow(lj.sigma_2 / r, 3.0);
	return lj.m4_epsilon * r * (r - 1);
}

void lj_pair_force(double x1[], double x2[], double* force, LJPotential lj)
{
	// the force[DIM] acts on the x1
	double r, sigma_r_6;
	int i;
	r = 0;
	for (i = 0; i < DIM; i++)
	{
		r += pow((x1[i] - x2[i]), 2.0);
		//printf("\t\t\t\t\t%f, %f, %f\n", x1[i], x2[i], r);
	}
	//printf(" r^2 == %f -- %f %f %f | %f %f %f", r, x1[0], x1[1], x1[2], x2[0], x2[1], x2[2]);
	r = 1 / r;
	sigma_r_6 = pow(lj.sigma_2 * r, 3.0);
	for (i = 0; i < DIM; i++)
	{
		force[i] = -lj.m4_epsilon * (x1[i] - x2[i]) * r * sigma_r_6 * (6.0 - 12.0 * sigma_r_6);
		//printf("%30.20f\n", force[i]);
	}
}

double lj_pot_monatomic_v(ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj)
{
	// for the monatomic fluid
	// use the verlet list
	int i, j, k;
	double en;
	double x[DIM];
	en = 0.0;

	//printf("%d\n", *(vl->num + 2));
	for (i = 0; i < pl->num; i++)
	{
		//printf("%d\n", *(vl->num + i));
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			//printf("%d, %d, %d\n", i, j, *(vl->num + i));
			//system("pause");exit(EXIT_FAILURE);
			for (k = 0; k < DIM; k++)
			{
				x[k] = (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k];
			}
			en += lj_pair_pot((pl->list + i)->x, x, lj);
		}
	}
	return en; // repeat calculate the pair energy
}

double lj_pot_monatomic_v_1p(ParticleList* pl, int* vl_x, int num, Particle* par, LJPotential lj, Ensemble* ense)
{
	// vl_x, num is the nparticle^th
	// for the monatomic fluid
	// use the verlet list
	// ergodic the relation between all particles in a Verlet list and one particle
	int i, j;
	double en;
	double x[DIM];
	//printf("%d\n", num);
	en = 0.0;
	for (j = 0; j < num * 2; j += 2)
	{
		//printf(" -- %d\n", *(vl_x + j));
		for (i = 0; i < DIM; i++)
		{
			//printf(" -- -- -- %f -%f, %f\n", par->x[i],(pl->list + *(vl_x + j))->x[i], box_index(*(vl_x + j + 1), i) * ense->h[i][i]);
			x[i] = (pl->list + *(vl_x + j))->x[i] + box_index(*(vl_x + j + 1), i) * ense->h[i][i];
		}
		en += lj_pair_pot(par->x, x, lj);
		//printf(" -- -- %f\n", en);
	}
	return en;
}

double lj_pot_monatomic_p(ParticleList* pl, LJPotential lj)
{
	// for the monatomic fluid
	// ergodic all particles
	int i, j;
	double en;
	en = 0.0;
	// pl->num > 2
	for (i = 1; i < pl->num; i++)
		for (j = 0; j < i; j++)
		{
			en += lj_pair_pot((pl->list + i)->x, (pl->list + j)->x, lj);
		}
	return en;
}

double lj_pot_monatomic_p_1p(ParticleList* pl, Particle* par, LJPotential lj, int par_index)
{
	// for the monatomic fluid
	// ergodic the relation between all particles and one particle
	int i;
	double en;
	en = 0.0;
	for (i = 0; i < par_index; i++)
	{
		en += lj_pair_pot((pl->list + i)->x, par->x, lj);
		//printf("**** %f ****, %f, %f \n", lj_pair_pot((pl->list + i)->x, par->x, lj), (pl->list + i)->x[0], par->x[0]);
	}
	for (i = par_index + 1; i < pl->num; i++)
	{
		en += lj_pair_pot((pl->list + i)->x, par->x, lj);
		//printf("**** %f ****, %f, %f \n", lj_pair_pot((pl->list + i)->x, par->x, lj), (pl->list + i)->x[0], par->x[0]);
	}
	return en;
}

//-------- End of The LJ Potential object --------