#include "define.h"
#include "mc.h"
#include "unit.h"
#include "lib.h"
#include "particle.h"
#include "info.h"


void mc_sub_step(MCInfo* mci, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj);
void mc_sub_step_demon(MCInfo* mci, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj);

//-------- The Monte Carlo object --------

int init_mc(MCInfo* mci, MCFun* mcf, Input inputinfo)
{
	mci->mc_step_num = inputinfo.mc_step; // !!!!!
	mci->mc_info_num = mci->mc_step_num;
	mci->mc_info_buff = INFO_BUFF_SIZE;
	mci->fac_x = inputinfo.mc_xscal;
	mci->fac_p = inputinfo.mc_pscal;
	mci->baro.scalV = inputinfo.baro_scal_v * pow(unit.bohrlang, 3.0);
	mci->baro.mc_accept_num = 0;
	mci->baro.mc_attempt_num = 0;
	mci->steplength_change = inputinfo.mc_steplength_change;
	if (mci->steplength_change)
		printf(" using the adjustable MC step length ...\n");
	mci->mc_accept_num = 0;
	mci->mc_attempt_num = 0;
	mcf->mc_step = NULL;
	mci->demon = 0;


	if (inputinfo.method == METHOD_MC)
	{
		switch (inputinfo.ensemble) {
		case ENSEMBLE_NVE:
			printf(" Using the NVE ensemble \n");
			mcf->mc_step = mc_step_nve;
			break;
		case ENSEMBLE_NVT:
			printf(" Using the NVT ensemble \n");
			mcf->mc_step = mc_step_nvt;
			break;
		case ENSEMBLE_NPT:
			printf(" Using the NPT ensemble \n");
			mcf->mc_step = mc_step_npt;
			break;
		default:
			printf(" no effectice ensemble mark \n");
			return -1;
		}
	}
	return 0;
}


void mc_sub_step(MCInfo* mci, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj)
{
	// change a particle or other variables
	double rand;
	int rand_p;
	double delta_en;
	int i;
	Particle par_tmp;
	par_tmp.subnum = 1;
	init_particle(&par_tmp);
	while ((rand_p = (int)(rand_std() * pl->num)) == pl->num); // choice the trial move particle
	//printf("rand_p : %d\n", rand_p);
	for (i = 0; i < DIM; i++)
	{
		par_tmp.x[i] = (pl->list + rand_p)->x[i] + rand_d1() * mci->fac_x;
		par_tmp.p[i] = (pl->list + rand_p)->p[i] + rand_d1() * mci->fac_p;
		//printf("%f, %f, %f, %f\n", par_tmp.x[i], (pl->list + rand_p)->x[i], par_tmp.p[i], (pl->list + rand_p)->p[i]);
//#ifdef PERRIODIC
//		// periodic boundary
//		par_tmp.x[i] -= floor(par_tmp.x[i] / ense->h[i][i]) * ense->h[i][i];
//#endif	
	}
	delta_en = 0;
#ifdef VERLET_USE

	delta_en = lj_pot_monatomic_v_1p(pl, vl->x + rand_p * vl->numMax * 2, vl->num_total[rand_p], &par_tmp, lj, ense) \
		- lj_pot_monatomic_v_1p(pl, vl->x + rand_p * vl->numMax * 2, vl->num_total[rand_p], pl->list + rand_p, lj, ense);

	//for(i = 0; i < vl->num[rand_p] * 2; i += 2)
	//	printf("%d %f %f %f------- %d %f %f %f\n", rand_p, (pl->list + rand_p)->x[0], (pl->list + rand_p)->x[1], (pl->list + rand_p)->x[2], \
	//		*(vl->x + rand_p * vl->numMax * 2 + i),(pl->list + *(vl->x + rand_p * vl->numMax * 2 + i))->x[0],\
	//		(pl->list + *(vl->x + rand_p * vl->numMax * 2 + i))->x[1], (pl->list + *(vl->x + rand_p * vl->numMax * 2 + i))->x[2]);

#else
	delta_en = lj_pot_monatomic_p_1p(pl, &par_tmp, lj, rand_p) - lj_pot_monatomic_p_1p(pl, pl->list + rand_p, lj, rand_p);
#endif // VERLET_USE

	//printf("delta--%f\n", delta_en);
	//system("pause");exit(EXIT_FAILURE);
	for (i = 0; i < DIM; i++)
	{
		delta_en += (pow(par_tmp.p[i], 2.0) - pow((pl->list + rand_p)->p[i], 2.0)) * 0.5 / (pl->list + rand_p)->mass[0];
		//printf("%f %f %f\n", par_tmp.p[i], (pl->list + rand_p)->p[i], (pl->list + rand_p)->mass[i]);
	}
	//printf("delta p   --%f\n", delta_en);
	rand = rand_std();
	mci->mc_attempt_num++;
	if (delta_en < 0 || rand < exp(-delta_en * ense->beta))
	{
		//printf("%f, %f\n", rand, -delta_en);
		for (i = 0; i < DIM; i++)
		{
			(pl->list + rand_p)->x[i] = par_tmp.x[i];
			(pl->list + rand_p)->p[i] = par_tmp.p[i];
			//printf("%f %f; %f %f\n", (pl->list + rand_p)->x[i], par_tmp.x[i], (pl->list + rand_p)->p[i], par_tmp.p[i]);
		}
		mci->mc_accept_num++;
	}

	//printf("%f\n", (double)mci->mc_accept_num / (double)mci->mc_attempt_num);
	if (mci->steplength_change && mci->mc_attempt_num >= 10)
	{
		if (mci->mc_accept_num < 0.25 * mci->mc_attempt_num)
		{
			mci->fac_x = mci->fac_x / 1.1;
			mci->fac_p = mci->fac_p / 1.1;
		}
		else if (mci->mc_accept_num > 0.75 * mci->mc_attempt_num)
		{
			mci->fac_x = min(mci->fac_x * 1.1, ense->h[0][0] * 0.005);
			mci->fac_p = min(mci->fac_p * 1.1, sqrt(pl->list->mass[0] / ense->beta) * 0.3);
		}
		mci->mc_accept_num = 0;
		mci->mc_attempt_num = 0;
	}
	
	free_particle(&par_tmp);
}

void mc_sub_step_demon(MCInfo* mci, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj)
{
	// the nve sub step
	// change a particle or other variables
	int rand_p;
	double delta_en;
	int i;
	Particle par_tmp;
	par_tmp.subnum = 1;
	init_particle(&par_tmp);
	while ((rand_p = (int)(rand_std() * pl->num)) == pl->num); // choice the trial move particle
	//printf("rand_p : %d\n", rand_p);
	for (i = 0; i < DIM; i++)
	{
		par_tmp.x[i] = (pl->list + rand_p)->x[i] + rand_d1() * mci->fac_x;
		par_tmp.p[i] = (pl->list + rand_p)->p[i] + rand_d1() * mci->fac_p;
		//printf("%f, %f, %f, %f\n", par_tmp.x[i], (pl->list + rand_p)->x[i], par_tmp.p[i], (pl->list + rand_p)->p[i]);
//#ifdef PERRIODIC
//		// periodic boundary
//		par_tmp.x[i] -= floor(par_tmp.x[i] / ense->h[i][i]) * ense->h[i][i];
//#endif	
	}
	delta_en = 0;
#ifdef VERLET_USE

	delta_en = lj_pot_monatomic_v_1p(pl, vl->x + rand_p * vl->numMax * 2, vl->num_total[rand_p], &par_tmp, lj, ense) \
		- lj_pot_monatomic_v_1p(pl, vl->x + rand_p * vl->numMax * 2, vl->num_total[rand_p], pl->list + rand_p, lj, ense);
#else
	delta_en = lj_pot_monatomic_p_1p(pl, &par_tmp, lj, rand_p) - lj_pot_monatomic_p_1p(pl, pl->list + rand_p, lj, rand_p);
#endif // VERLET_USE

	//printf("delta--%f\n", delta_en);
	//system("pause");exit(EXIT_FAILURE);
	for (i = 0; i < DIM; i++)
	{
		delta_en += (pow(par_tmp.p[i], 2.0) - pow((pl->list + rand_p)->p[i], 2.0)) * 0.5 / (pl->list + rand_p)->mass[0];
		//printf("%f %f %f\n", par_tmp.p[i], (pl->list + rand_p)->p[i], (pl->list + rand_p)->mass[i]);
	}
	//printf("delta p   --%f\n", delta_en);
	mci->mc_attempt_num++;
	if (mci->demon > delta_en) // delta_en < 0 || ( delta_en > 0 && demon > delta_en )
	{
		mci->demon -= delta_en;
		//printf("%f, %f\n", mci->demon, delta_en);
		for (i = 0; i < DIM; i++)
		{
			(pl->list + rand_p)->x[i] = par_tmp.x[i];
			(pl->list + rand_p)->p[i] = par_tmp.p[i];
			//printf("%f %f; %f %f\n", (pl->list + rand_p)->x[i], par_tmp.x[i], (pl->list + rand_p)->p[i], par_tmp.p[i]);
		}
		mci->mc_accept_num++;
	}

	free_particle(&par_tmp);
}

void mc_barostat(ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj, Barostat* bs, int mark)
{
	// use the Monte Carlo method to control pressure
	int i, j, k;
	double mv2, pot1, pot2;
	double deltaV, deltaE;
	double ratio;
	double volume;
	double x1[DIM], x2[DIM];
	volume = ense->h[0][0] * ense->h[1][1] * ense->h[2][2];
	mv2 = 0;
	for (i = 0; i < pl->num; i++)
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				mv2 += pow((pl->list + i)->p[j * DIM + k], 2.0) / (pl->list + i)->mass[j];
			}
		}
	pot1 = lj_pot_monatomic_v(pl, vl, ense, lj);
	deltaV = rand_d1() * 0.5 * bs->scalV;
	ratio = pow((volume + deltaV) / volume, 1.0 / 3.0);
	pot2 = 0;
	for (i = 0; i < pl->num; i++)
	{
		//printf("%d\n", *(vl->num + i));
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			//printf("%d, %d, %d\n", i, j, *(vl->num + i));
			//system("pause");exit(EXIT_FAILURE);
			for (k = 0; k < DIM; k++)
			{
				x1[k] = (pl->list + i)->x[k] * ratio;
				x2[k] = ((pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k]) * ratio;
			}
			pot2 += lj_pair_pot(x1, x2, lj);
		}
	}
	deltaE = 0;
	if (mark == MC_BAROSTAT_TOTAL_EN)
		// U = T + V
		deltaE += 0.5 * mv2 * (ratio * ratio - 1.0);
	deltaE += pot2 - pot1 + ense->press0[0][0] * deltaV - (double)pl->num * /*(double)pl->list->subnum * */unit.kb * ense->temp0 * log((volume + deltaV) / volume);
	//printf("-- %30.20f -- %30.20f -- %30.20f -- %30.20f -- %30.20f\n", 0.5 * mv2 * (ratio * ratio - 1.0), pot2 - pot1, ense->press0[0][0] * deltaV, (double)pl->num * unit.kb * ense->temp0 * log((volume + deltaV) / volume), deltaE);
	//printf("delta E: %f\n", deltaE);
	bs->mc_attempt_num++;
	if (deltaE < 0 || rand_std() < exp(-ense->beta * deltaE))
	{
		bs->mc_accept_num++;
		//printf("accepted\n");
		for (i = 0; i < pl->num; i++)
			for (j = 0; j < (pl->list + i)->subnum; j++)
				for (k = 0; k < DIM; k++)
				{
					(pl->list + i)->x[j * DIM + k] *= ratio;
				}
		for (i = 0; i < DIM; i++)
			ense->h[i][i] *= ratio;
		if (mark == MC_BAROSTAT_TOTAL_EN)
		{
			for (i = 0; i < pl->num; i++)
				for (j = 0; j < (pl->list + i)->subnum; j++)
					for (k = 0; k < DIM; k++)
					{
						(pl->list + i)->p[j * DIM + k] *= ratio;
					}
		}
	}
	if (bs->mc_attempt_num >= 10)
	{
		if (bs->mc_accept_num < 0.25 * bs->mc_attempt_num)
		{
			bs->scalV = bs->scalV / 1.1;
		}
		else if (bs->mc_accept_num > 0.75 * bs->mc_attempt_num)
		{
			bs->scalV = min(bs->scalV * 1.1, ense->h[0][0] * ense->h[1][1] * ense->h[2][2] * 0.3);
		}
		bs->mc_accept_num = 0;
		bs->mc_attempt_num = 0;
		//printf("%f\n", bs->scalV / pow(unit.bohrlang, 3.0));
	}
}

void mc_step_nvt(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj)
{
	// a special Monte Carlo step
	int i;

	for (i = 0; i < pl->num; i++)
	{
		mc_sub_step(mci, pl, ense, vl, lj);
	}
}

void mc_step_npt(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj)
{
	// Monte Carlo + Barostat
	int i;

	for (i = 0; i < pl->num; i++)
	{
		mc_sub_step(mci, pl, ense, vl, lj);
	}
	mc_barostat(pl, vl, ense, lj, &mci->baro, MC_BAROSTAT_POT_EN);
}

void mc_step_nve(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj)
{
	// demon method
	int i, j, k;
	double ene;
	particle_ene(pl, ense, vl, lj);
	mci->demon = ense->energy0 - ense->energy;
	if (mci->demon < 0)
	{
		printf(" The initial energy is too little\n");
		exit(EXIT_FAILURE);
	}
	for (i = 0; i < pl->num; i++)
	{
		mc_sub_step_demon(mci, pl, ense, vl, lj);
	 }
}

//-------- End of The Monte Carlo object --------

