#include "define.h"
#include "md.h"
#include "unit.h"
#include "mc.h"
#include "lib.h"
#include "info.h"


int init_barostat(Barostat* baro, Ensemble* ense, Input* inp);

void propagator_1(MDInfo* mdi, ParticleList* pl, Ensemble* ense, double delta_t);

void propagator_1_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, double delta_t);

void propagator_2(MDInfo* mdi, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj, double delta_t);

void propagator_2_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, double delta_t);

void propagator_2_peps(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, double delta_t);

void propagator_nhc_sy(MDInfo* mdi, ParticleList* pl, Ensemble* ense, NHChain* nhc, double delta_t);

void propagator_nhc_sy_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, NHChain* nhc, double delta_t);

void propagator_nhc_part(MDInfo* mdi, ParticleList* pl, Ensemble* ense, NHChain* nhc, double delta_t);

void propagator_nhc_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, NHChain* nhc, double delta_t);

void propagator_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense);


//-------- The Nose - Hoover chain object --------

int init_nhc(NHChain* nhc, Ensemble* ense, int aim_dim, int total_num, int chain_length, double tau)
{
	// init the sub pointer of the nhc( local, global or barostat )
	// aim_dim = num_particle * num_atom * DIM for local
	int i, j;
	nhc->num = aim_dim;
	nhc->chain_length = chain_length;
	nhc->num_1 = total_num / aim_dim;
	if (nhc->chain_length <= 0)
	{
		printf(" wrong: nhc_chain = 0 for the Nose-Hoover chain method\n");
		return -1;
	}
	if ((nhc->eta = (double*)malloc(aim_dim * chain_length * sizeof(double))) == NULL)
	{
		perror("malloc_eta");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((nhc->peta = (double*)malloc(aim_dim * chain_length * sizeof(double))) == NULL)
	{
		perror("malloc_peta");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((nhc->Q = (double*)malloc(chain_length * sizeof(double))) == NULL)
	{
		perror("malloc_Q");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((nhc->G = (double*)malloc(aim_dim * chain_length * sizeof(double))) == NULL)
	{
		perror("malloc_nhc");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	

	*(nhc->Q) = nhc->num_1 * tau * tau * unit.kb * ense->temp0;
	for (j = 1; j < chain_length; j++)
		*(nhc->Q + j) = tau * tau * unit.kb * ense->temp0;

	for (i = 0; i < aim_dim; i++)
	{
		for (j = 0; j < chain_length; j++)
		{
			*(nhc->eta  + i * chain_length + j) = 0.5 * rand_d1();
			*(nhc->peta + i * chain_length + j) = sqrt(*(nhc->Q + j) * unit.kb * ense->temp0) * rand_gauss();
		}
	}
	return 0;
}

int free_nhc(NHChain* nhc)
{
	if (nhc->chain_length <= 0)
	{
		printf(" wrong: nhc_chain = 0 for the Nose-Hoover chain method\n");
		return -1;
	}
	free(nhc->eta);
	free(nhc->peta);
	free(nhc->Q);
	free(nhc->G);
	return 0;
}

//-------- End of The Nose - Hoover chain object --------

//-------- The Molecular Dynamic object --------


int init_barostat(Barostat* baro, Ensemble* ense, Input* inp)
{
	baro->weps = 3.0 * ((double)inp->particle_num[0] * (double)inp->particle_atom_num + 1.0) * pow(inp->baro_tau, 2.0) * unit.kb * ense->temp0;
	baro->eps = 0.1 * rand_d1();
	baro->peps = sqrt(baro->weps * unit.kb * ense->temp0) * rand_gauss();
	//fprintf( debugfp, " ---------------- %f,   %f,   %f,   %f\n", baro->eps, inp->baro_tau, baro->weps, ense->beta);
}

int init_md(MDInfo* mdi, MDFun* mdf, Input* inp, Ensemble* ense, ParticleList* pl, NHChain* nhc, NHChain* nhc_baro, Barostat* baro)
{
	int i;
	mdi->md_step_num = (int)((double)inp->time / inp->deltaT);
	mdi->md_info_num = mdi->md_step_num; // get ever step information
	mdi->delta_t = inp->deltaT * unit.timelfs; // unit fs -> a.u.
	mdi->sy_num = 7;
	mdi->sy_respa_num = inp->nhc_respa_num;
	mdi->sy_omega[0] = 0.784513610477560;
	mdi->sy_omega[6] = mdi->sy_omega[0];
	mdi->sy_omega[1] = 0.235573213359357;
	mdi->sy_omega[5] = mdi->sy_omega[1];
	mdi->sy_omega[2] = -1.17767998417887;
	mdi->sy_omega[4] = mdi->sy_omega[2];
	mdi->sy_omega[3] = 1.0;
	mdf->propagator = NULL;
	mdi->baro.mc_accept_num = 0;
	mdi->baro.mc_attempt_num = 0;
	mdi->nhc_baro_sw = false;
	mdi->nhc_sw = false;
	mdi->step = 0;
	for (i = 0; i < 3; i++)
		mdi->sy_omega[3] -= mdi->sy_omega[i] * 2.0;

	mdi->alpha = 1.0 + 1.0 / ((double)inp->particle_num[0] * (double)inp->particle_atom_num);
	mdi->anderson_nu = 1.0 / mdi->delta_t * 0.01;
	mdi->nu_dt = mdi->anderson_nu * mdi->delta_t;

	// choice the propagator function
	if (inp->method == METHOD_HMC)
	{
		mdf->propagator = propagator_nve;
	}
	else if (inp->method == METHOD_MD)
	{
		switch (inp->ensemble)
		{
		case ENSEMBLE_NVE:
			printf(" Using the NVE ensemble\n");
			mdf->propagator = propagator_nve;
			break;
		case ENSEMBLE_NVT:
			printf(" Using the NVT ensemble\n");
			if (inp->thermostat == THERMOSTATAND)
			{
				printf(" thermostat = 1\n");
				mdf->propagator = propagator_nvt_anderson;
			}
			else if (inp->thermostat == THERMOSTATNHC)
			{
				printf(" thermostat = 2\n");
				init_nhc(nhc, ense, pl->num * pl->list->subnum * DIM, pl->num * pl->list->subnum * DIM, inp->nhc_length, inp->nhc_tau);
				mdf->propagator = propagator_nvt;
				mdi->nhc_sw = true;
			}
			break;
		case ENSEMBLE_NPT:
			printf(" Using the NPT ensemble\n");
			if (inp->barostat == MCBAROSTAT)
			{
				mdi->baro.scalV = inp->baro_scal_v * pow(unit.bohrlang, 3.0);
				if (inp->thermostat == THERMOSTATAND)
				{
					printf(" thermostat = %d\n", inp->thermostat);
					mdf->propagator = propagator_npt_mcbarostat_anderson;
				}
				else if (inp->thermostat == THERMOSTATNHC)
				{
					printf(" thermostat = %d\n", inp->thermostat);
					// nhc_part
					init_nhc(nhc, ense, pl->num * pl->list->subnum * DIM, pl->num * pl->list->subnum * DIM, inp->nhc_length, inp->nhc_tau);
					mdf->propagator = propagator_npt_mcbarostat;
					mdi->nhc_sw = true;
				}
				else
				{
					printf(" Error: wrong thermostat and barostat combination\n");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
					system("pause");
#else
					getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND

					exit(EXIT_FAILURE);
				}
				printf(" barostat = %d\n", inp->barostat);
			}
			else if (inp->barostat == EXPBAROSTAT)
			{
				if (inp->thermostat == THERMOSTATNHC)
				{
					printf(" thermostat = %d\n", inp->thermostat);
					printf(" barostat = %d\n", inp->barostat);
					// nhc_part
					init_nhc(nhc, ense, pl->num * pl->list->subnum * DIM, pl->num * pl->list->subnum * DIM, inp->nhc_length, inp->nhc_tau);
					mdi->nhc_sw = true;
					//barostat
					init_barostat(baro, ense, inp);
					mdi->nhc_baro_sw = true;
					// nhc_baro
					init_nhc(nhc_baro, ense, 1, 1, inp->nhc_length, inp->nhc_tau);
					mdf->propagator = propagator_npt;
				}
				else
				{
					printf(" Error: wrong thermostat and barostat combination\n");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
					system("pause");
#else
					getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND

					exit(EXIT_FAILURE);
				}
			}
			break;
		default:
			printf(" no effectice ensemble mark \n");
			return -1;
		}
	}
	return 0;
}




void propagator_1(MDInfo* mdi, ParticleList* pl, Ensemble* ense, double delta_t)
{
	int i, j, k;
	//fprintf(debugfp, " propagator_1\n");
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				*((pl->list + i)->x + j * DIM + k) += delta_t * *((pl->list + i)->p + j * DIM + k) / *((pl->list + i)->mass + j);
			}
		}
	}
}

void propagator_1_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, double delta_t)
{
	// the propagator iL1 in the NPT ensemble with the barostate variable epsilon
	int i, j, k;
	double veps, exp_veps_dt;
	veps = baro->peps / baro->weps;
	exp_veps_dt = exp(veps * delta_t);
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				*((pl->list + i)->x + j * DIM + k) = *((pl->list + i)->x + j * DIM + k) * exp_veps_dt + \
					*((pl->list + i)->p + j * DIM + k) / *((pl->list + i)->mass + j) * (exp_veps_dt - 1.0) / veps;
			}
		}
	}
	// update the epsilon
	baro->eps += veps * delta_t;
	// update the volume
	//fprintf( debugfp, "++%f++, %f, %f, %f\n", ense->h[0][0], baro->peps, veps, exp_veps_dt);
	for(i = 0; i < DIM; i++)
		ense->h[i][i] *= exp_veps_dt;
	//fprintf( debugfp, "--%f--%f--%f--\n", ense->h[0][0], ense->h[1][1], ense->h[2][2]);
}

void propagator_2(MDInfo* mdi, ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj, double delta_t)
{
	int i, j, k, s1, s2;
	double force[3];
	double x[3];
	//fprintf(debugfp, " propagator_2\n");
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			for (k = 0; k < DIM; k++)
				x[k] = (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k];
			
			for (s1 = 0; s1 < (pl->list + i)->subnum; s1++)
			{
				lj_pair_force((pl->list + i)->x + s1 * DIM, x, force, lj);
				//fprintf( debugfp, "  %d ( %d ) %d --- force: %f %f %f ---\n", i, *((vl->x + i * vl->numMax * 2) + j), j, force[0], force[1], force[2]);
				for (k = 0; k < DIM; k++)
				{
					//fprintf( debugfp, "i %d j  %d s1 %d k %d --- p: %f x: %f ---\n",i , j, s1, k, *((pl->list + i)->p + s1 * DIM + k), *((pl->list + i)->x + s1 * DIM + k));
					*((pl->list + i)->p + s1 * DIM + k) += delta_t * force[k];
					*((pl->list + *(vl->x + i * vl->numMax * 2 + j))->p + s1 * DIM + k) -= delta_t * force[k];
				}
			}
		}
	}
}

void propagator_2_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, double delta_t)
{
	int i, j, k, s1;
	int vir;
	double force[3];
	double x[3];
	double veps, exp_veps_dt;
	veps = -mdi->alpha * baro->peps / baro->weps;
	exp_veps_dt = exp(veps * delta_t);
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			for (k = 0; k < DIM; k++)
				x[k] = (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k];
			
			//fprintf( debugfp, "  %d ( %d ) %d %d %d --- %f ---\n", i, *((vl->x + i * vl->numMax * 2) + j), j, s1, s2, force[0]);
			for (s1 = 0; s1 < (pl->list + i)->subnum; s1++)
			{
				lj_pair_force((pl->list + i)->x + s1 * DIM, x, force, lj);
				for (k = 0; k < DIM; k++)
				{
					//if(i == 0 && j <= 2)
						//fprintf( debugfp,  "%d %d %d --- %f --- ***",i , *(vl->x + i * vl->numMax * 2 + j),  k, *((pl->list + i)->p + s1 * DIM + k));
					*((pl->list + i)->p + s1 * DIM + k) = *((pl->list + i)->p + s1 * DIM + k) * exp_veps_dt + force[k] * (exp_veps_dt - 1.0) / veps;
					vir = *(vl->x + i * vl->numMax * 2 + j);
					*((pl->list + vir)->p + s1 * DIM + k) = *((pl->list + vir)->p + s1 * DIM + k) * exp_veps_dt	- force[k] * (exp_veps_dt - 1.0) / veps;
					//fprintf( debugfp, "%d %d %d --- %f --- ***", i, *(vl->x + i * vl->numMax * 2 + j), k, *((pl->list + i)->p + s1 * DIM + k));
				}
			}
			//if (i == 0 && j <= 2)
				//fprintf( debugfp,  "\n");
		}
	}
	
}

void propagator_2_peps(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, double delta_t)
{
	double Geps;
	//particle_info(pl, ense, vl, 0);
	particle_mv2(pl, ense);
	particle_virial(pl, ense, vl, lj);
	Geps = mdi->alpha * ense->mv2 + ense->virial - triproduct(ense->h[0]) * ense->press0[0][0] * (double)DIM;
	baro->peps += Geps * delta_t;
	//fprintf( debugfp,  " --- %f --- %f --- %f -- %f -- %f -- %f\n", baro->peps, Geps, ense->mv2, ense->virial, triproduct(ense->h[0]), ense->h[0][0]);
}

void propagator_nhc_sy(MDInfo* mdi, ParticleList* pl, Ensemble* ense, NHChain* nhc, double delta_t)
{
	int i, j, k, m;
	int dof;
	double kbT;
	kbT = unit.kb * ense->temp0;

	//fprintf(debugfp, " nhc_sy: delta_t: %f\n", delta_t);
	// update the G factor
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				dof = ((i * (pl->list + i)->subnum + j) * DIM + k) * nhc->chain_length;
				nhc->G[dof] = pow(*((pl->list + i)->p + j * DIM + k), 2.0) / *(((pl->list + i)->mass + j)) - kbT;
				//fprintf( debugfp,  "G[0]: ---- i %d, j %d, k %d --- p %f g %f\n", i, j, k, *((pl->list + i)->p + j * DIM + k), nhc->G[dof]);
				for (m = 1; m < nhc->chain_length; m++)
				{
					nhc->G[dof + m] = pow(nhc->peta[dof + m - 1], 2.0) / nhc->Q[m - 1] - kbT;
					//fprintf(debugfp, "G[%d]: ---- i %d, j %d, k %d --- peta %f q %f g %f f %f\n", m, i, j, k, nhc->peta[dof + m - 1], nhc->Q[m - 1], nhc->G[dof + m], pow(nhc->peta[dof + m - 1], 2.0) / nhc->Q[m - 1] - kbT);
				}
			}
		}
	}


	//for (i = 0; i < nhc->chain_length; i++)
	//	fprintf( debugfp, "             G: %f,  Q: %f\n", nhc->G[i], nhc->Q[i]);

	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				dof = ((i * (pl->list + i)->subnum + j) * DIM + k) * nhc->chain_length;
				//fprintf(debugfp," dof: %d\npeta1 -- 4: %f, %f\n", dof, nhc->peta[dof + nhc->chain_length - 1], delta_t * 0.5 * nhc->G[dof + nhc->chain_length - 1]);
				nhc->peta[dof + nhc->chain_length - 1] += delta_t * 0.5 * nhc->G[dof + nhc->chain_length - 1];
				for (m = nhc->chain_length - 2; m >= 0; m--)
				{
					//fprintf( debugfp,  "peta1 -- 3: %f, %f, %f, %f\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1], nhc->Q[m + 1], exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]));
					nhc->peta[dof + m] *= exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]);
					//fprintf( debugfp,  "peta1 -- 2: %f, %f\n", nhc->peta[dof + m], nhc->G[dof + m]);
					nhc->peta[dof + m] += delta_t * 0.5 * nhc->G[dof + m];
					//fprintf( debugfp,  "peta1 -- 1: %f, %f\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1]);
					nhc->peta[dof + m] *= exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]);
					//fprintf( debugfp,  "peta1 -- 0: %f, %f -------------- %d %d %d %d %d\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1], i, j, k, dof, m);
				}
				for (m = 0; m < nhc->chain_length; m++)
				{
					nhc->eta[dof + m] += delta_t * nhc->peta[dof + m] / nhc->Q[m];
					//fprintf(debugfp, "eta: %d %f\n", m, nhc->eta[dof + m]);
				}
				//fprintf( debugfp,  "sy: %d, %d -------- %f  %f %f %f\n", i, k, *((pl->list + i)->p + j * DIM + k), exp(-delta_t * nhc->peta[dof] / nhc->Q[0]), nhc->peta[dof], nhc->Q[0]);
				*((pl->list + i)->p + j * DIM + k) *= exp(-delta_t * nhc->peta[dof] / nhc->Q[0]);
			}
			//fprintf( debugfp,  "\n");
		}
	}

	

	//fprintf( debugfp, "********************\n");

	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				dof = ((i * (pl->list + i)->subnum + j) * DIM + k) * nhc->chain_length;
				nhc->G[dof] = pow(*((pl->list + i)->p + j * DIM + k), 2.0) / *(((pl->list + i)->mass + j)) - kbT;
				//fprintf(debugfp, "G[0]2: ---- %d, %d, %d --- %f  %f\n", i, j, k, *((pl->list + i)->p + j * DIM + k), nhc->G[dof]);
				for (m = 1; m < nhc->chain_length; m++)
				{
					nhc->G[dof + m] = pow(nhc->peta[dof + m - 1], 2.0) / nhc->Q[m - 1] - kbT;
					//fprintf(debugfp, "G[%d]2: ---- %d, %d, %d --- %f  %f  %f  %f\n", m, i, j, k, nhc->peta[dof + m - 1], nhc->Q[m - 1], nhc->G[dof + m], pow(nhc->peta[dof + m - 1], 2.0) / nhc->Q[m - 1] - kbT);
				}
			}
		}
	}

	//for (i = 0; i < nhc->chain_length; i++)
	//	fprintf( debugfp, "             G2: %f\n", nhc->G[i]);

	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				dof = ((i * (pl->list + i)->subnum + j) * DIM + k) * nhc->chain_length;
				for (m = 0; m < nhc->chain_length - 1; m++)
				{
					//fprintf( debugfp,  "-----------------%d %d %d %d %d------------------------\n", i, j, k, dof, m);
					//fprintf( debugfp,  "peta2 -- 0: %f, %f, %f, %f\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1], nhc->Q[m + 1], exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]));
					nhc->peta[dof + m] *= exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]);
					//fprintf( debugfp,  "peta2 -- 1: %f, %f\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1]);
					nhc->peta[dof + m] += delta_t * 0.5 * nhc->G[dof + m];
					//fprintf( debugfp,  "peta2 -- 2: %f, %f\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1]);
					nhc->peta[dof + m] *= exp(-delta_t * 0.25 * nhc->peta[dof + m + 1] / nhc->Q[m + 1]);
					//fprintf( debugfp,  "peta2 -- 3: %f, %f -------------- %d %d %d %d %d\n", nhc->peta[dof + m], -delta_t * 0.25 * nhc->peta[dof + m + 1], i, j, k, dof, m);
				}
				nhc->peta[dof + nhc->chain_length - 1] += delta_t * 0.5 * nhc->G[dof + nhc->chain_length - 1];
				//fprintf(debugfp, "peta2 -- 4: %f, %f\n", nhc->peta[dof + nhc->chain_length - 1], delta_t * 0.5 * nhc->G[dof + nhc->chain_length - 1]);
			}
		}
	}
	//system("pause");exit(EXIT_FAILURE);
}

void propagator_nhc_sy_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, NHChain* nhc, double delta_t)
{
	int m;
	double kbT;
	kbT = unit.kb * ense->temp0;

	nhc->G[0] = pow(baro->peps, 2.0) / baro->weps - kbT;
	//fprintf( debugfp,  "%f,   %f, %f, %f\n", nhc->G[0], pow(baro->peps, 2.0), baro->weps, kbT);
	for (m = 1; m < nhc->chain_length; m++)
		nhc->G[m] = pow(nhc->peta[m - 1], 2.0) / nhc->Q[m - 1] - kbT;

	nhc->peta[nhc->chain_length - 1] += delta_t * 0.5 * nhc->G[nhc->chain_length - 1];
	//fprintf( debugfp, "1   %f, %f, %f\n", baro->peps, exp(-delta_t * nhc->peta[0] / nhc->Q[0]), nhc->peta[0]);
	for (m = nhc->chain_length - 2; m >= 0; m--)
	{
		//fprintf( debugfp, " first  %d   %f,   %f,   %f\n", m, nhc->peta[m], exp(-delta_t * 0.25 * nhc->peta[m + 1] / nhc->Q[m + 1]), nhc->G[m]);
		nhc->peta[m] *= exp(-delta_t * 0.25 * nhc->peta[m + 1] / nhc->Q[m + 1]);
		nhc->peta[m] += delta_t * 0.5 * nhc->G[m];
		nhc->peta[m] *= exp(-delta_t * 0.25 * nhc->peta[m + 1] / nhc->Q[m + 1]);
		//fprintf( debugfp, " second %d   %f\n", m, nhc->peta[m]);
	}
	for (m = 0; m < nhc->chain_length; m++)
	{
		nhc->eta[m] += delta_t * nhc->peta[m] / nhc->Q[m];
	}
	baro->peps *= exp(-delta_t * nhc->peta[0] / nhc->Q[0]);
	//fprintf( debugfp, "2   %f\n", baro->peps);
	nhc->G[0] = pow(baro->peps, 2.0) / baro->weps - kbT;
	for (m = 1; m < nhc->chain_length; m++)
		nhc->G[m] = pow(nhc->peta[m - 1], 2.0) / nhc->Q[m - 1] - kbT;

	for (m = 0; m < nhc->chain_length - 1; m++)
	{
		nhc->peta[m] *= exp(-delta_t * 0.25 * nhc->peta[m + 1] / nhc->Q[m + 1]);
		nhc->peta[m] += delta_t * 0.5 * nhc->G[m];
		nhc->peta[m] *= exp(-delta_t * 0.25 * nhc->peta[m + 1] / nhc->Q[m + 1]);
	}
	nhc->peta[nhc->chain_length - 1] += delta_t * 0.5 * nhc->G[nhc->chain_length - 1];
}

void propagator_nhc_part(MDInfo* mdi, ParticleList* pl, Ensemble* ense, NHChain* nhc, double delta_t)
{
	int i, j;
	for (i = 0; i < mdi->sy_num; i++)
	{
		for (j = 0; j < mdi->sy_respa_num; j++)
			propagator_nhc_sy(mdi, pl, ense, nhc, delta_t * mdi->sy_omega[i] / mdi->sy_respa_num);
	}
}

void propagator_nhc_baro(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, NHChain* nhc, double delta_t)
{
	int i, j;
	for (i = 0; i < mdi->sy_num; i++)
	{
		for (j = 0; j < mdi->sy_respa_num; j++)
			propagator_nhc_sy_baro(mdi, pl, ense, baro, nhc, delta_t * mdi->sy_omega[i] / mdi->sy_respa_num);
	}
}

void propagator_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense)
{
	int i, j, k;
	double rand_p;
	for (i = 0; i < pl->num; i++)
	{
		if (rand_std() <= mdi->nu_dt)
		{
			for (j = 0; j < (pl->list + i)->subnum; j++)
			{
				rand_p = rand_gauss() * sqrt(ense->temp0 * unit.kb * (pl->list + i)->mass[j]);
				for (k = 0; k < DIM; k++)
				{
					(pl->list + i)->p[j * DIM + k] = rand_p;
				}
			}
		}
	}
}

void propagator_nvt(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	propagator_nhc_part(mdi, pl, ense, &nhc, mdi->delta_t * 0.5);
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
	propagator_1(mdi, pl, ense, mdi->delta_t);
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
	propagator_nhc_part(mdi, pl, ense, &nhc, mdi->delta_t * 0.5);
}

void propagator_nvt_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
	propagator_1(mdi, pl, ense, mdi->delta_t);
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
	propagator_anderson(mdi, pl, ense);
}

void propagator_nve(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
	propagator_1(mdi, pl, ense, mdi->delta_t);
	propagator_2(mdi, pl, ense, vl, lj, mdi->delta_t * 0.5);
}

void propagator_npt(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	propagator_nhc_baro(mdi, pl, ense, baro, &nhc_baro, mdi->delta_t * 0.5);
	propagator_nhc_part(mdi, pl, ense, &nhc, mdi->delta_t * 0.5);
	propagator_2_peps(mdi, pl, ense, baro, vl, lj, mdi->delta_t * 0.5);
	propagator_2_baro(mdi, pl, ense, baro, vl, lj, mdi->delta_t * 0.5);
	propagator_1_baro(mdi, pl, ense  , baro, mdi->delta_t);
	propagator_2_baro(mdi, pl, ense, baro, vl, lj, mdi->delta_t * 0.5);
	propagator_2_peps(mdi, pl, ense, baro, vl, lj, mdi->delta_t * 0.5);
	propagator_nhc_part(mdi, pl, ense, &nhc, mdi->delta_t * 0.5);
	propagator_nhc_baro(mdi, pl, ense, baro, &nhc_baro, mdi->delta_t * 0.5);
}

void propagator_npt_mcbarostat(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	mc_barostat(pl, vl, ense, lj, &mdi->baro, MC_BAROSTAT_POT_EN);
	propagator_nvt(mdi, pl, ense, baro, vl, lj, nhc, nhc_baro);
	mc_barostat(pl, vl, ense, lj, &mdi->baro, MC_BAROSTAT_POT_EN);
}

void propagator_npt_mcbarostat_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	mc_barostat(pl, vl, ense, lj, &mdi->baro, 2);
	propagator_nvt_anderson(mdi, pl, ense, baro, vl, lj, nhc, nhc_baro);
	mc_barostat(pl, vl, ense, lj, &mdi->baro, 2);
}



//-------- End of The Molecular Dynamic object --------