#include "define.h"
#include "particle.h"
#include "lib.h"
#include "unit.h"
#include "pot.h"
#include "verlet.h"


//-------- The particle object --------
int init_particle(Particle* part)
{
	if ((part->mass = (double*)malloc(part->subnum * sizeof(double))) == NULL)
	{
		perror("malloc_Particle_mass");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((part->x = (double*)malloc(DIM * part->subnum * sizeof(double))) == NULL)
	{
		perror("malloc_Particle_x");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((part->p = (double*)malloc(DIM * part->subnum * sizeof(double))) == NULL)
	{
		perror("malloc_Particle_p");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	return 0;
}


int free_particle(Particle* part)
{
	free(part->mass);
	free(part->x);
	free(part->p);
	return 0;
}


int init_particle_list(ParticleList* partlist, int num_list, int* num_particle, int* subnum_particle)
{
	int i, j, k;
	printf(" Init the particle lsit ...\n");
	k = 0;
	for (i = 0; i < num_list; i++)
	{
		(partlist + i)->num = *(num_particle + i);
		if (((partlist + i)->list = (Particle*)malloc((partlist + i)->num * sizeof(Particle))) == NULL)
		{
			perror("malloc_ParticleList_list");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}
		for (j = 0; j < (partlist + i)->num; j++)
		{
			((partlist + i)->list + j)->subnum = *(subnum_particle + k);
			k++;
			init_particle((partlist + i)->list + j);
		}
	}
	return 0;
}

// set the max # of the need
int init_particle_list_const(ParticleList* partlist, int num_list, int num_particle, int subnum_particle)
{
	int i, j;
	printf(" Init the particle lsit ...\n");
	for (i = 0; i < num_list; i++)
	{
		(partlist + i)->num = num_particle;
		if (((partlist + i)->list = (Particle*)malloc((partlist + i)->num * sizeof(Particle))) == NULL)
		{
			perror("malloc_ParticleList_list");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}
		for (j = 0; j < (partlist + i)->num; j++)
		{
			((partlist + i)->list + j)->subnum = subnum_particle;
			init_particle((partlist + i)->list + j);
		}
	}
	return 0;
}

int free_particle_list(ParticleList* partlist, int num_list)
{
	int i, j;
	printf(" Free the memory of particle list ...\n");
	for (i = 0; i < num_list; i++)
	{
		for (j = 0; j < (partlist + i)->num; j++)
			free_particle((partlist + i)->list + j);
	}
	free(partlist);
	return 0;
}

int save_trajectory(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list)
{
	int i, j, dim_value;
	dim_value = DIM;

	fopen_n(&(fl->traj_fp), "trajectory.dat", "wb", "fopen_traj");

	fwrite(&dim_value, sizeof(int), 1, fl->traj_fp);
	fwrite(ense->h, sizeof(double), dim_value * dim_value, fl->traj_fp);
	fwrite(&num_list, sizeof(int), 1, fl->traj_fp);

	fprintf(fl->log_fp, " save the trajectory\n");
	printf(" saving the trajectory ... \n");
	for (i = 0; i < num_list; i++)
	{
		fwrite(&pl[i].num, sizeof(int), 1, fl->traj_fp);
		for (j = 0; j < pl[i].num; j++)
		{
			fprintf(fl->log_fp, "%d  %d  %d \n", pl[i].num, j, (pl[i].list + j)->subnum);
			fprintf(fl->log_fp, " %d ", fwrite(&(pl[i].list + j)->subnum, sizeof(int), 1, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fwrite((pl[i].list + j)->mass, sizeof(double), (pl[i].list + j)->subnum, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fwrite((pl[i].list + j)->x, sizeof(double), (pl[i].list + j)->subnum * DIM, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fwrite((pl[i].list + j)->p, sizeof(double), (pl[i].list + j)->subnum * DIM, fl->traj_fp));
			fprintf(fl->log_fp, "\n");
		}
	}
	fclose(fl->traj_fp);
	return 0;
}

int read_trajectory(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list)
{
	int i, j, k, dim_value, num;
	fopen_n(&(fl->traj_fp), "trajectory.dat", "rb", "fopen_traj");
	fread(&dim_value, sizeof(int), 1, fl->traj_fp);
	if (dim_value != DIM)
	{
		printf(" Error: The dim (%d) of the traiectory is not agreed with the dim (%d) of this program !!! ", dim_value, DIM);
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	fread(ense->h, sizeof(double), dim_value * dim_value, fl->traj_fp);
	fread(&num, sizeof(int), 1, fl->traj_fp);
	if (num != num_list)
	{
		printf(" Error: The pl num (%d) of the traiectory is not agreed with the pl num (%d) of this program !!! ", num, num_list);
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	fprintf(fl->log_fp, " read the trajectory\n");
	printf(" reading the trajectory ... \n");
	fprintf(fl->log_fp, " dim = %d, num_list = %d \n", dim_value, num);
	// init the ParticleList * num_list

	for (i = 0; i < num_list; i++)
	{
		fread(&pl[i].num, sizeof(int), 1, fl->traj_fp);
		// init the Particle * pl[i].num
		for (j = 0; j < pl[i].num; j++)
		{
			fprintf(fl->log_fp, "%d  %d  %d \n", pl[i].num, j, (pl[i].list + j)->subnum);
			fprintf(fl->log_fp, " %d ", fread(&(pl[i].list + j)->subnum, sizeof(int), 1, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fread((pl[i].list + j)->mass, sizeof(double), (pl[i].list + j)->subnum, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fread((pl[i].list + j)->x, sizeof(double), (pl[i].list + j)->subnum * DIM, fl->traj_fp));
			fprintf(fl->log_fp, " %d ", fread((pl[i].list + j)->p, sizeof(double), (pl[i].list + j)->subnum * DIM, fl->traj_fp));
			fprintf(fl->log_fp, "%d\n", feof(fl->traj_fp));
			fprintf(fl->log_fp, "\n");
		}
	}
	fclose(fl->traj_fp);
	return 0;
}

int coord_pic(ParticleList* pl, Ensemble* ense, FileList* fl)
{
	int i, j, k, ibox;

	fopen_n(&fl->coordx_fp, "coord_x.txt", "w", "fopen_n_coordx");
	//fopen_n(&fl->coordp_fp, "coord_x.txt", "w", "fopen_n_coordp");

	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (ibox = 0; ibox < DIM * DIM; ibox++)
			{
				for (k = 0; k < DIM; k++)
				{
					fprintf(fl->coordx_fp, "%30.20f ", (pl->list + i)->x[j * DIM + k] + box_index(ibox, k) * ense->h[k][k]);
					//fprintf(fl->coordp_fp, "%30.20f ", (pl->list + i)->p[j * DIM + k]);
				}
				fprintf(fl->coordx_fp, "\n");
				//fprintf(fl->coordp_fp, "\n");
			}
		}
	}

	//fclose(fl->coordp_fp);
	fclose(fl->coordx_fp);
}


double total_mass_cal(ParticleList* pl, int num_list)
{
	double total_mass;
	int i, j, k;
	total_mass = 0;
	for (i = 0; i < num_list; i++)
		for (j = 0; j < (pl + i)->num; j++)
			for (k = 0; k < (((pl + i)->list + j)->subnum); k++)
				total_mass += *(((pl + i)->list + j)->mass + k);
	return total_mass;
}

int init_coord(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list, int mark)
{
	int i, j, k, l, dim_c, rand;
	double* node_list;
	double total_node_num;


	switch (mark)
	{
	case RANDOM_INIT_COORD:
		total_node_num = pow((double)NODE_NUM, 3.0);
		//printf("%d, %d\n", NODE_NUM, (int)total_node_num);
		if ((node_list = (double*)malloc((int)total_node_num * 3 * sizeof(ParticleList))) == NULL)
		{
			perror("malloc_ParticleList");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}
		for (i = 0; i < num_list; i++)
		{
			for (l = 0; l < NODE_NUM; l++)
				for (j = 0; j < NODE_NUM; j++)
					for (k = 0; k < NODE_NUM; k++)
					{
						*(node_list + (l * NODE_NUM * NODE_NUM + j * NODE_NUM + k) * 3) = \
							(double)(ense + i)->h[0][0] / ((double)NODE_NUM + 1.0) * ((double)l + 1.0);

						*(node_list + (l * NODE_NUM * NODE_NUM + j * NODE_NUM + k) * 3 + 1) = \
							(double)(ense + i)->h[1][1] / ((double)NODE_NUM + 1.0) * ((double)j + 1.0);

						*(node_list + (l * NODE_NUM * NODE_NUM + j * NODE_NUM + k) * 3 + 2) = \
							(double)(ense + i)->h[2][2] / ((double)NODE_NUM + 1.0) * ((double)k + 1.0);

						//printf("%d  :  %d - %d - %d\n", (l * 100 + j * 10 + k), k, j, l);
					}
			//for (l = 0; l < (int)total_node_num; l++)
			//	printf("node: %f, %f, %f\n", *(node_list + l * 3), *(node_list + l * 3 + 1), *(node_list + l * 3 + 2));
			for (j = 0; j < (pl + i)->num; j++)
				for (k = 0; k < (((pl + i)->list + j)->subnum); k++)
				{
					*(((pl + i)->list + j)->mass + k) = AMASS; // !!!!!
					while (1)
					{
						// choice one node from the lattice nodes as the particle postion
						rand = (int)(rand_std() * total_node_num);
						if (rand == (int)total_node_num || node_list[rand * 3] < 0)
							continue;

						for (dim_c = 0; dim_c < DIM; dim_c++)
						{
							*(((pl + i)->list + j)->x + k * DIM + dim_c) = node_list[rand * 3 + dim_c] + \
								(double)(ense + i)->h[dim_c][dim_c] / ((double)NODE_NUM + 1.0) * 0.25 * rand_d1();
							node_list[rand * 3 + dim_c] = -1;
							*(((pl + i)->list + j)->p + k * DIM + dim_c) = sqrt((ense + i)->temp0 * unit.kb * \
								* (((pl + i)->list + j)->mass + k)) * rand_gauss();
							//printf("%d %d %d %d -- %f %f %f\n", i, j, k, dim_c, *(((pl + i)->list + j)->x \
							//+ k * DIM + dim_c), *(((pl + i)->list + j)->p + k * DIM + dim_c), rand_gauss());
						}
						//printf(" choice : %d\n", rand);
						break;
					}
				}
		}
		ense->total_mass = total_mass_cal(pl, num_list);
		return 0;

	case TRAJECTORY_COORD:
		read_trajectory(pl, ense, fl, num_list);
		ense->total_mass = total_mass_cal(pl, num_list);
		return 0;

	default:
		printf(" error: wrong init coord mark\n");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
}


void translation(ParticleList* pl, Ensemble* ense)
{
	int i, j, k;
	for (i = 0; i < pl->num; i++)
	{
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
#ifdef PERRIODIC
				// periodic boundary
				* ((pl->list + i)->x + j * DIM + k) -= floor(*((pl->list + i)->x + j * DIM + k) / ense->h[k][k] + 1e-12) * ense->h[k][k];
#endif	
			}
		}
	}
}

//-------- End of The particle  object --------

