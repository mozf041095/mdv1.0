#include "define.h"
#include "hmc.h"
#include "unit.h"
#include "lib.h"



int init_hmc(HMCInfo* hmci, HMCFun* hmcf, Input* inp, Ensemble* ense, ParticleList* pl, NHChain* nhc, NHChain* nhc_baro, Barostat* baro)
{
	//printf(" In the MD part:\n");
	init_md(&hmci->mdi, &hmcf->mdf, inp, ense, pl, nhc, nhc_baro, baro);
	//printf(" In the MC part:\n");
	init_mc(&hmci->mci, &hmcf->mcf, *inp);
	return 0;
}

void hmc_step(HMCInfo* hmci, HMCFun* hmcf, ParticleList* pl, ParticleList* pl_tmp, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro)
{
	int i, j, k;
	double delta_E;

	for (i = 0; i < pl->num; i++)
		for (j = 0; j < (pl->list + i)->subnum; j++)
			for (k = 0; k < DIM; k++)
			{
				(pl->list + i)->p[j * DIM + k] = rand_gauss() * sqrt((pl->list + i)->mass[j] * ense->temp0 * unit.kb);
			}
	particle_ene(pl, ense, vl, lj);
	delta_E = ense->energy;

	// init the x
	for (i = 0; i < pl->num; i++)
		for (j = 0; j < (pl->list + i)->subnum; j++)
			for (k = 0; k < DIM; k++)
			{
				//printf("%d %d %d", i, j, k);
				*((pl_tmp->list + i)->x + j * DIM + k) = *((pl->list + i)->x + j * DIM + k);
			}


	for (i = 0; i < hmci->mdi.md_step_num; i++)
	{
		hmcf->mdf.propagator(&hmci->mdi, pl, ense, baro, vl, lj, nhc, nhc_baro);
	}

	particle_ene(pl, ense, vl, lj);
	delta_E = ense->energy - delta_E;

	//printf("%f\n", delta_E);
	if (delta_E >= 0 && rand_std() >= exp(-ense->beta * delta_E))
	{
		for (i = 0; i < pl->num; i++)
			for (j = 0; j < (pl->list + i)->subnum; j++)
				for (k = 0; k < DIM; k++)
				{
					(pl->list + i)->x[j * DIM + k] = (pl_tmp->list + i)->x[j * DIM + k];
				}
	}
}
//-------- The Hybrid MC method --------