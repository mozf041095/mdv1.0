#include "define.h"
#include "file.h"

unsigned int BKDRHash(char* str);

//-------- The file object --------

void fopen_n(FILE** fpp, char* filename, char* type, char* error)
{
#ifdef WIN_CONDITION
	errno_t err;
	err = fopen_s(fpp, filename, type);
	if (err != 0)
	{
		perror(error);
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
#else
	if ((*fpp = fopen(filename, type)) == NULL)
	{
		perror(error);
		getchar(); 
		exit(EXIT_FAILURE);
	}
#endif // WIN_CONDITION
}

int init_file(FileList* fl)
{
	fopen_n(&(fl->input_fp), "input.txt", "r", "fopen_input");
	fopen_n(&(fl->temp_fp), "temp.dat", "w", "fopen_temp");
	fopen_n(&(fl->energy_fp), "energy.dat", "w", "fopen_energy");
	fopen_n(&(fl->log_fp), "log.dat", "w", "fopen_log");
	fopen_n(&(fl->output_fp), "output.dat", "w", "fopen_output");
	fopen_n(&(fl->press_fp), "pressure.dat", "w", "fopen_pressure");
	fopen_n(&(fl->volume_fp), "volume.dat", "w", "fopen_volume");
	fopen_n(&(fl->density_fp), "density.dat", "w", "fopen_density");
	return 0;
}

int fclose_file(FileList* fl)
{
	fclose(fl->energy_fp);
	fclose(fl->input_fp);
	fclose(fl->log_fp);
	fclose(fl->output_fp);
	fclose(fl->temp_fp);
	fclose(fl->press_fp);
	fclose(fl->volume_fp);
	fclose(fl->density_fp);
	return 0;
}

//-------- End of The file object --------

//-------- The input file object --------

unsigned int BKDRHash(char* str)
{
	// change a str to the only hash value
	unsigned int seed = 131; // 31 131 1313 13131 131313 etc..
	unsigned int hash = 0;

	while (*str)
	{
		hash = hash * seed + (*str++);
	}

	return (hash & 0x7FFFFFFF);
}



int read_input_file(Input* input, FILE* fp)
{
	int i, j;
	int index_num, index_name, num_term;
	char buff[FILE_LINE_SIZE], name[FILE_SUB_TERM][FILE_TERM_SIZE];
	char num[FILE_SUB_TERM][FILE_TERM_SIZE];
	// default values
	input->energy = 0;
	for (i = 0; i < DIM; i++)
		for (j = 0; j < DIM; j++)
		{
			input->h[i][j] = 0;
			input->press[i][j] = 0;
		}
	for (i = 0; i < FILE_SUB_TERM; i++)
		input->particle_num[i] = 0;
	input->temp = 0;
	input->volume = 0;
	input->nhc_length = 0;
	input->particle_atom_num = 1;

	// read the file
	printf(" reading the input file ... \n");
	while (fgets(buff, FILE_LINE_SIZE, fp) != NULL)
	{
		i = 0;
		index_name = 0;
		index_num = 0;
		num_term = 0;
		while (buff[i] != '\0' && buff[i] != '#' && i < FILE_LINE_SIZE)
		{
			// '#' is the comment symbol
			j = 0;
			while ((buff[i] >= '0' && buff[i] <= '9') || buff[i] == '.' || buff[i] == '*')
			{
				num[index_num][j] = buff[i];
				++i;
				++j;
			}
			if (j != 0)
			{
				num[index_num][j] = '\0';
				++index_num;
				++num_term;
				continue;
			}
			while ((buff[i] >= 'A' && buff[i] <= 'Z') || (buff[i] >= 'a' && buff[i] <= 'z') || buff[i] == '_')
			{
				name[index_name][j] = buff[i];
				++i;
				++j;
			}
			if (j != 0)
			{
				name[index_name][j] = '\0';
				++index_name;
				++num_term;
				continue;
			}
			++i;
		}
		// change part
		if (num_term >= 2)
		{
			switch (BKDRHash(name[0]))
			{
			case 252979321:
				// particle_num
				input->species_num = index_num;
				for (i = 0; i < index_num; i++)
					input->particle_num[i] = atoi(num[0]);
				break;
			case 1634717869:
				// pressure
				if (index_num != 9)
				{
					printf(" error: wrong pressure date\n");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
					system("pause");
#else
					getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
					exit(EXIT_FAILURE);
				}
				for (i = 0; i < DIM; i++)
					for (j = 0; j < DIM; j++)
					{
						input->press[i][j] = atof(num[i * DIM + j]);
						//printf(" %d - %d -- %f -- \n", i, j, input->press[i][j]);
					}
				break;
			case 436497614:
				// volume
				input->volume = atof(num[0]);
				break;
			case 379410840:
				// temperature
				input->temp = atof(num[0]);
				break;
			case 1404881028:
				// energy
				input->energy = atof(num[0]);
				break;
			case 104:
				// h
				if (index_num != 9)
				{
					printf(" error: wrong h date\n");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
					system("pause");
#else
					getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
					exit(EXIT_FAILURE);
				}
				for (i = 0; i < DIM; i++)
					for (j = 0; j < DIM; j++)
						input->h[i][j] = atof(num[i * DIM + j]);
				break;
			case 1471344341:
				// truncate_r
				input->truncate_r = atof(num[0]);
				break;
			case 333688065:
				// method
				input->method = atoi(num[0]);
				break;
			case 856133768:
				// atom_num
				input->particle_atom_num = atoi(num[0]);
				break;
			case 124783408:
				// nhc_length
				input->nhc_length = atoi(num[0]);
				break;
			case 690257402:
				// nhc_tau
				input->nhc_tau = atof(num[0]);
				break;
			case 938441293:
				// ensemble
				input->ensemble = atoi(num[0]);
				break;
			case 1456838261:
				// baro_tau
				input->baro_tau = atof(num[0]);
				break;
			case 262594841:
				// time
				input->time = atof(num[0]);
				break;
			case 992851536:
				// deltaT
				input->deltaT = atof(num[0]);
				break;
			case 1260137015:
				// trajectory
				input->trajectory = atoi(num[0]);
				break;
			case 1196663233:
				// mc_step
				input->mc_step = atoi(num[0]);
				break;
			case 1501800080:
				// barostat
				input->barostat = atoi(num[0]);
				//printf(" ----- %d ----- \n", input->barostat);
				break;
			case 1914885065:
				// baro_scal_v
				input->baro_scal_v = atof(num[0]);
				break;
			case 37826847:
				// thermostat
				input->thermostat = atoi(num[0]);
				break;
			case 1645206799:
				// test_rdf
				input->test_rdf = (bool)atoi(num[0]);
				break;
			case 1466792554:
				// mc_xscal
				input->mc_xscal = atof(num[0]);
				break;
			case 1258276834:
				// mc_pscal
				input->mc_pscal = atof(num[0]);
				break;
			case 1911884030:
				// coord_xp_output
				input->coord_xp_output = (bool)atoi(num[0]);
				break;
			case 1926614080:
				// mc_steplength_change
				input->mc_steplength_change = (bool)atoi(num[0]);
				break;
			case 1468223954:
				// nhc_respa_num
				input->nhc_respa_num = atoi(num[0]);
			default:
				break;
			}
		}
		// end change part

	}
	return 0;
}
//-------- End of The input file object --------