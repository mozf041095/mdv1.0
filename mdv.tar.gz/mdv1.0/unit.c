#include "define.h"
#include "unit.h"
//-------- The basic unit object --------

int init_unit()
{
	unit.ang1bohr = 0.52917721092e0;
	unit.bohrlang = 1.0 / unit.ang1bohr;
	unit.kb = 3.1668114e-6; // a.u. boltamann constant
	unit.amunit = 1822.7;
	unit.fsltime = 2.418884326505e-2;
	unit.timelfs = 1.0 / unit.fsltime;
	unit.eV1hatree = 27.21138602;
	unit.hatree1eV = 1.0 / unit.eV1hatree;
	unit.rePlank = 1.0;
	unit.Avogadro = 6.022141510e23;
	unit.kPa1P = 2.9421912e10;
	unit.P1kPa = 1.0 / unit.kPa1P;
	unit.density1au = 9.1093829140e-1 / pow(unit.ang1bohr, 3.0);

#ifdef AU_UNIT
	// input & output use the a.u.
	unit.ang1bohr = 1;
	unit.bohrlang = 1.0 / unit.ang1bohr;
	unit.fsltime = 1;
	unit.timelfs = 1.0 / unit.fsltime;
	unit.eV1hatree = 1;
	unit.hatree1eV = 1.0 / unit.eV1hatree;
	unit.rePlank = 1.0;
	unit.kPa1P = 1;
	unit.P1kPa = 1.0 / unit.kPa1P;
	unit.density1au = 9.1093829140e-1 / pow(unit.ang1bohr, 3.0);
#endif // AU_UNIT

}
//-------- End of The basic unit object --------
