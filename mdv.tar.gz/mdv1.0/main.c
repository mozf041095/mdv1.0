// This is a test program for the Monte Carlo sampling on the molecular dynamics trajectories.
// date: 2020/11/5

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>


#define TOTAL_H // calculate the H = K + V
#define SYS_RAND // make rand() <=> U(0, 1)


#define Sign_f(x) ( (x)>0? (x) : -1*(x) )
#ifdef SYS_RAND
#define rand() ((double)rand()/(double)RAND_MAX)
#endif

#define DELTA_COOR 6 // x, px, y, py, z, pz
#define CO_MA 2 // x, p
#define MAX_FILE_NUM 3


//information
#define INFO_TEMP_INDEX 1
#define INFO_ENE_INDEX 2

//potential
#define LJPOT_INDEX 1

//print
#define LOG_PRINT 0
#define TEMP_PRINT 1
#define ENE_PRINT 2

// constant
#define PI 3.14159265358979


struct Unit_ {
	double ang1bohr;
	double bohrlang;
	double kb;
	double amunit;
	double fsltime;
	double timelfs;
} unit;

struct Factor_mc {
	double fp, fq;
} fac_mc;

struct Information {
	int count;
	int sub_count;
	int out_count;
	double* total_e;
	double* temp;
};

struct Lennard_Jones {
	double epsilon, sigma;
} lj_fac;

struct Box_Mess {
	double x[3];
};

struct Environment_ {
	double temp;
} envir;

struct Particle_ {
	double mass;
	int num;
} particle;

struct System_ {
	bool parallel_condition;
} sys;

// functions
double gauss_rand();
int init_coord(double* coord, int dim, struct Box_Mess* box);
int init();
double potential_energy(double* coord, int dim, int type_pot);
int mc_step(double* coord, double* coord_tmp, int dim, double mass, struct Box_Mess* box);
int get_info(double* coord, int dim, double mass, struct Information* info, int mark);
int file_print(int index, FILE** fp, struct Information* info, int step, int shift);


int main()
{
	double* coord; // (qi, pi)*n
	double* coord_tmp; // save for the mid variable
	struct Information* info;
	double mass;
	int step_num;
	int i, j;
	int dim;
	int info_save_block;
	int info_step, total_info_num;
	struct Box_Mess* box;
	char tmpch;
	double delta_t;
	
	FILE* fp[MAX_FILE_NUM];

	// init
	printf("initializing ...\n");
	if (init() != 0)
		exit(EXIT_FAILURE);
	
	step_num = (int)1e4 + 1;
	dim = particle.num * DELTA_COOR;
	info_save_block = 1; // for save to the file
	total_info_num = 100;
	info_step = (int)(step_num / total_info_num);
	for (i = 0; i < MAX_FILE_NUM; i++)
		fp[i] = NULL;

	// open the file
	fopen_s(&fp[LOG_PRINT], "log.txt", "w");
	if (fp[LOG_PRINT] == NULL)
	{
		perror("fopen_s");
		exit(EXIT_FAILURE);
	}
	fopen_s(&fp[TEMP_PRINT], "temperature.txt", "w");
	if (fp[TEMP_PRINT] == NULL)
	{
		perror("fopen_s");
		exit(EXIT_FAILURE);
	}
	fopen_s(&fp[ENE_PRINT], "energy.txt", "w");
	if (fp[ENE_PRINT] == NULL)
	{
		perror("fopen_s");
		exit(EXIT_FAILURE);
	}

	//  allocate the memory
	printf("applying for memory ...\n");
	if ((coord = (double*)malloc(dim * sizeof(double))) == NULL)
	{
		perror("malloc_coord");
		exit(EXIT_FAILURE);
	}
	if ((coord_tmp = (double*)malloc(dim * sizeof(double))) == NULL)
	{
		perror("malloc_coord_tmp");
		exit(EXIT_FAILURE);
	}
	if ((info = (struct Information*)malloc(sizeof(struct Information))) == NULL)
	{
		perror("malloc_info");
		exit(EXIT_FAILURE);
	}
	if ((info->temp = (double*)malloc(info_save_block * sizeof(double))) == NULL)
	{
		perror("malloc_info_temp");
		exit(EXIT_FAILURE);
	}
	if ((info->total_e = (double*)malloc(info_save_block * sizeof(double))) == NULL)
	{
		perror("malloc_info_total_e");
		exit(EXIT_FAILURE);
	}
	if ((box = (struct Box_Mess*)malloc(sizeof(struct Box_Mess))) == NULL)
	{
		perror("malloc_box");
		exit(EXIT_FAILURE);
	}

	info->count = 0;
	info->out_count = 0;

	// coordinate init
	printf("initializing the coordinate and momentum ...\n");
	init_coord(coord, dim, box);

	// Monte Carlo
	printf("Monte Carlo looping ...\n");

	for (i = 0; i < step_num; i++)
	{
		info->sub_count = 0;
		for (j = 0; j < particle.num; j++)
		{
			mc_step(coord, coord_tmp, dim, particle.mass, box);
			++info->sub_count;
			//printf("mc sub step = %d \n", info->sub_count);
		}
		// info
		if (info->count % info_step == 0)
		{
			get_info(coord, dim, particle.mass, info, INFO_ENE_INDEX);
			get_info(coord, dim, particle.mass, info, INFO_TEMP_INDEX);
			printf("total energy: %-30.10f, temperature: %-30.10f, mc step: %-10d \n", \
				* (info->total_e + info->out_count), *(info->temp + info->out_count), info->count);
			++info->out_count;
			if (info->out_count == info_save_block)
			{
				info->out_count = 0;
				// fprintf the data to the file
				for (j = 0; j < info_save_block; j++)
				{
					file_print(LOG_PRINT, fp, info, info->count - (info_save_block - j - 1) * info_step, j);
					file_print(TEMP_PRINT, fp, info, info->count - (info_save_block - j - 1) * info_step, j);
					file_print(ENE_PRINT, fp, info, info->count - (info_save_block - j - 1) * info_step, j);
				}
			}

		}
		++info->count;
		//printf("mc step = %d \n", info->count);
	}

	for (j = 0; j < info->out_count; j++)
	{
		file_print(LOG_PRINT, fp, info, info->count - (info->out_count - j - 1) * info_step - 1, j);
		file_print(TEMP_PRINT, fp, info, info->count - (info->out_count - j - 1) * info_step - 1, j);
		file_print(ENE_PRINT, fp, info, info->count - (info->out_count - j - 1) * info_step - 1, j);
	}

	// free the memory
	free(coord);
	free(coord_tmp);
	free(info->temp);
	free(info->total_e);
	free(info);
	free(box);

	for (i = 0; i < MAX_FILE_NUM; i++)
		if (fp[i] != NULL)
			fclose(fp[i]);



	system("pause");
	exit(EXIT_SUCCESS);

}

int file_print(int index, FILE** fp, struct Information* info, int step, int shift)
{
	switch (index)
	{
	case LOG_PRINT:
		fprintf(fp[LOG_PRINT], "total energy: %-30.10f, temperature: %-30.10f, mc step: %-10d \n", \
			* (info->total_e + shift), *(info->temp + shift), step);
		break;
	case TEMP_PRINT:
		fprintf(fp[TEMP_PRINT], "%-10d %-30.10f\n", step, *(info->temp + shift));
		break;
	case ENE_PRINT:
		fprintf(fp[ENE_PRINT], "%-10d %-30.10f\n", step, *(info->total_e + shift));
		break;
	default:
		break;
	}
}

double gauss_rand()
{
	// return a rand from N(0, 1)
	// Box - Muller
	double eta, chi;
	eta = rand();
	chi = rand();

	return sqrt(-2.0 * log(eta)) * cos(2.0 * PI * chi);

}

int init_coord(double* coord, int dim, struct Box_Mess* box)
{
	// input: dim
	// output: initialized coordinate
	int i, j;
	int num_partical;

	num_partical = particle.num ;

	// box init
	for (i = 0; i < 3; i++)
		box->x[i] = 10; // ( - x, x )


	// q coord
	for (i = 0; i < dim; i += DELTA_COOR)
	{
		for (j = 0; j < DELTA_COOR; j += CO_MA)
		{
			*(coord + i + j) = box->x[(int)(j / CO_MA)] * (2.0 * rand() - 1.0);
			//printf("%f, %d\n", *(coord + i + j), i + j);
		}
		//printf("*************\n");
		for (j = 1; j < DELTA_COOR; j += CO_MA)
		{
			*(coord + i + j) = gauss_rand() * sqrt(particle.mass * unit.kb * envir.temp);
			//printf("%f, %d\n", *(coord + i + j), i + j);
		}
		//printf("*************\n");
	}
	return 0;
}

int init()
{
	// aim: initialize the whole program basic variables;

	// unit of the atomic unit
	unit.ang1bohr = 0.52917721092e0;
	unit.bohrlang = 1.0 / unit.ang1bohr;
	unit.kb = 3.1668114e-6; // a.u. boltamann constant
	unit.amunit = 1822.7;
	unit.fsltime = 2.418884326505e-2;
	unit.timelfs = 1.0 / unit.fsltime;

	// step length of Monte Carlo
	fac_mc.fp = 0.01;
	fac_mc.fq = 0.01;

	// Lennard�CJones potential
	lj_fac.epsilon = 10.22 * unit.kb;
	lj_fac.sigma = 2.556; // armstrong for helium

	envir.temp = 300;

	particle.num = 10;
	particle.mass = 4.00260325 * unit.amunit;

	sys.parallel_condition = 1;

	return 0;
}

double potential_energy(double* coord, int dim, int type_pot)
{
	// input: coord is a pointer of the coordinate array
	// input: dim is the size of the memory of coord data
	// input: type_pot is the index of different potential
	// output: pot is the potenital of the system
	// error: function returns -1

	int i, ic, j, jc;
	double pot_tmp;
	double r;

	if (coord == NULL)
		return -1;

	pot_tmp = 0;

	switch (type_pot)
	{
	case LJPOT_INDEX:
		// L-J potential
		for (i = DELTA_COOR; i < dim; i += DELTA_COOR)
			for (j = 0; j < i; j += DELTA_COOR)
			{
				//printf(" %d, %d \n", i, j);
				r = 0.;
				for (ic = 0; ic < DELTA_COOR; ic += CO_MA)
					//printf(" %f, %d \n", r, ic);
					r += pow(*(coord + i + ic) - *(coord + j + ic), 2);
				r = sqrt(r);
				pot_tmp += 4 * lj_fac.epsilon * (pow(lj_fac.sigma / r, 12) - pow(lj_fac.sigma / r, 6));
			}
		return pot_tmp;
	default:
		return 0;
	}
}


int mc_step(double* coord, double* coord_tmp, int dim, double mass, struct Box_Mess* box)
{
	// input: coord is the pointer of the coordinate array (q,p)
	// input: dim is the size of the memory of coord data
	// output: new coord
	// error: return -1
	int i, j, rand_int;
	double Delta_energy;
	double rand_num;
	double tmp;

	if (coord == NULL || coord_tmp == NULL)
		return -1;

	while (rand_int = (int)(rand() * particle.num ) == particle.num );

	for (i = 0; i < dim; i++)
	{
		*(coord_tmp + i) = *(coord + i);
		//printf("%d: %f \n", i, *(coord + i));
	}

	if(!sys.parallel_condition)
		for (j = 0; j < DELTA_COOR; j += CO_MA)
		{
			*(coord_tmp + rand_int * DELTA_COOR + j) += fac_mc.fq * (rand() - 0.5) * 2.0;
			// need the boundary conditions

		}
	else
		for (j = 0; j < DELTA_COOR; j += CO_MA)
		{
			*(coord_tmp + rand_int * DELTA_COOR + j) += fac_mc.fq * (rand() - 0.5) * 2.0;
			*(coord_tmp + rand_int * DELTA_COOR + j) -= (int)((*(coord_tmp + rand_int * DELTA_COOR + j) + box->x[(int)(j/CO_MA)])/(2.0* box->x[(int)(j / CO_MA)])) * box->x[(int)(j / CO_MA)];
		}
	for (j = 1; j < DELTA_COOR; j += CO_MA)
		*(coord_tmp + rand_int * DELTA_COOR + j) = gauss_rand() * sqrt(particle.mass * unit.kb * envir.temp);// += fac_mc.fp * (rand() - 0.5) * 2.0;

	Delta_energy = 0;
	if(!sys.parallel_condition)
		Delta_energy += potential_energy(coord_tmp, dim, LJPOT_INDEX) - potential_energy(coord, dim, LJPOT_INDEX);
	else
		Delta_energy += potential_energy(coord_tmp, dim, LJPOT_INDEX) - potential_energy(coord, dim, LJPOT_INDEX);
#ifdef TOTAL_H
	for (i = 0; i < dim; i += DELTA_COOR)
		for (j = 1; j < DELTA_COOR; j += CO_MA)
			Delta_energy += *(coord_tmp + i + j) * *(coord_tmp + i + j) / (2.0 * mass) \
			- *(coord + i + j) * *(coord + i + j) / (2.0 * mass);
#endif
	// kB T
	Delta_energy = Delta_energy / (unit.kb * envir.temp);
	rand_num = rand();
	if (Delta_energy < 0 || rand_num < exp(-Delta_energy)) // exp is expensive
		for (i = 0; i < dim; i++)
			*(coord + i) = *(coord_tmp + i);

	return 0;
}

int get_info(double* coord, int dim, double mass, struct Information* info, int mark)
{
	// input: coord & dim
	// input: mark is the index for different types
	// output: info
	int i, j, k;
	double mv2;
	double energy;


	switch (mark)
	{
	case INFO_TEMP_INDEX:

		// temp
		mv2 = 0;
		for (i = 0; i < dim; i += DELTA_COOR)
			for (j = 1; j < DELTA_COOR; j += CO_MA)
			{
				mv2 += *(coord + i + j) * *(coord + i + j) / mass;
			}
		*(info->temp + info->out_count) = mv2 / (3.0 * unit.kb * particle.num);
		return 0;
	case INFO_ENE_INDEX:
		mv2 = 0;
#ifdef TOTAL_H
		for (i = 0; i < dim; i += DELTA_COOR)
			for (j = 1; j < DELTA_COOR; j += CO_MA)
			{
				mv2 += *(coord + i + j) * *(coord + i + j) / mass;
			}
#endif
		energy = mv2 * 0.5 + potential_energy(coord, dim, LJPOT_INDEX);
		*(info->total_e + info->out_count) = energy / (particle.num);
		return 0;
	default:
		return -1;
	}
}