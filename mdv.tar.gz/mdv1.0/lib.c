#include "define.h"
#include "lib.h"


//-------- The time object --------
#ifdef WIN_CONDITION
int gettimeofday(struct timeval* tp, void* tzp)
{
	time_t clock;
	struct tm tm;
	SYSTEMTIME wtm;
	GetLocalTime(&wtm);
	tm.tm_year = wtm.wYear - 1900;
	tm.tm_mon = wtm.wMonth - 1;
	tm.tm_mday = wtm.wDay;
	tm.tm_hour = wtm.wHour;
	tm.tm_min = wtm.wMinute;
	tm.tm_sec = wtm.wSecond;
	tm.tm_isdst = -1;
	clock = mktime(&tm);
	tp->tv_sec = clock;
	tp->tv_usec = wtm.wMilliseconds * 1000;
	return (0);
}
#else

#endif // WIN_CONDITION

//-------- End of The time object --------

//-------- The random object --------

void init_rand()
{
	struct timeval tv;
	int num = 376483;
	gettimeofday(&tv, NULL);
	srand((unsigned int)(tv.tv_sec * 1000000 + tv.tv_usec) % num);
	printf(" Random seed = %u\n", (unsigned int)(tv.tv_sec * 1000000 + tv.tv_usec) % num);
}
double rand_d1()
{
	// U[-1,1]
	return (double)rand() / (double)RAND_MAX * 2.0 - 1.0;
}

double rand_std()
{
	//U[0,1]
	return (double)rand() / (double)RAND_MAX;
}

double rand_gauss()
{
	double x, y;
	x = 0;
	y = 0;
	while (x * y == 0)
	{
		x = rand_std();
		y = rand_std();
	}
	//printf("%f %f %f %f \n", x, log(x), y, sqrt(-2.0 * log(x)) * cos(2.0 * PI * y));
	return sqrt(-2.0 * log(x)) * cos(2.0 * PI * y);
}
//-------- End of The random object --------


//-------- The cmd control object --------
#ifdef WIN_CONDITION
void full_screen()
{
	HWND hwnd = GetForegroundWindow();
	ShowWindow(hwnd, SW_MAXIMIZE);
}
#endif // !WIN_CODITION
//-------- End of The cmd control object --------

//-------- The math lib --------

double triproduct(double* x)
{
	int i;
	double tmp;
	tmp = 1;
	for (i = 0; i < DIM; i++)
		tmp *= *(x + i * DIM + i);
	return tmp;
}

//-------- End of The math lib --------

int box_index(int line_index, int dim)
{
	switch (dim)
	{
	case 0:
		return (line_index) % 3 - 1;
	case 1:
		return (line_index) % 9 / 3 - 1;
	case 2:
		return (line_index) / 9 - 1;
	default:
		return 0;
	}
}

