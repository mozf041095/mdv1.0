#pragma once
#include "file.h"
#include "ensemble.h"



//-------- The particle object --------
// Use init_praticle_list, init_particle_list_const, free_particle_list
// need the follow code to init:
//	if ((partlist = (ParticleList*)malloc(num_list * sizeof(ParticleList))) == NULL)
//	{
//		perror("malloc_ParticleList");
//		system("pause");exit(EXIT_FAILURE);
//	}

typedef struct Particle_ {
	// The info of one particle( sphere, atomic. molecular ...)
	// malloc a large memory block, give the pointers differents addresses in the memory block
	int subnum;
	double* mass;
	double* x;
	double* p;
} Particle;

typedef struct ParticleList_ {
	// list of the particles
	int num;
	Particle* list;
} ParticleList;


int init_particle(Particle* part);

int free_particle(Particle* part);

int init_particle_list(ParticleList* partlist, int num_list, int* num_particle, int* subnum_particle);

int init_particle_list_const(ParticleList* partlist, int num_list, int num_particle, int subnum_particle);

int free_particle_list(ParticleList* partlist, int num_list);

int save_trajectory(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list);

int read_trajectory(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list);

int coord_pic(ParticleList* pl, Ensemble* ense, FileList* fl);

double total_mass_cal(ParticleList* pl, int num_list);

int init_coord(ParticleList* pl, Ensemble* ense, FileList* fl, int num_list, int mark);

void translation(ParticleList* pl, Ensemble* ense);

//-------- End of The particle object --------

