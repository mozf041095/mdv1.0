#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>
#include <time.h>


//################################# controlling mark #################################
// define for control the version of the program and the system function

//#define WIN_CONDITION
//#define UNBACKGROUND
//#define AU_UNIT

#define PERRIODIC // use the periodic condition
#define VERLET_USE // use the verlet list method

#ifdef WIN_CONDITION
#include <Windows.h>
#else
#include <unistd.h>
#include <sys/times.h>
#endif

//#define DEBUG_
#ifdef DEBUG_
void* debugfp;
#endif

//################################# system struct & constant #################################
// define the basic struct which is statics( don't change in the program)

#define DIM 3
#define BOXNUM 27
#define INFO_BUFF_SIZE 100 // the buffer size of the process infomation
#define AMASS 4.00260325 * unit.amunit // He
#define PI 3.14159265358979

#define FILE_LINE_SIZE 100
#define FILE_TERM_SIZE 20
#define FILE_SUB_TERM 11

#define INFO_NUM 10

#define min(a,b) (((a) < (b)) ? (a) : (b))

//################################# function handles #################################
// mark different methods
// used in the switch structure

#define HeLJ 1

#define ENSEMBLE_NVE 1
#define ENSEMBLE_NVT 2
#define ENSEMBLE_NPT 3

#define METHOD_MC 1
#define METHOD_MD 2
#define METHOD_HMC 3

#define MC_BAROSTAT_TOTAL_EN 1
#define MC_BAROSTAT_POT_EN   2

#define MCBAROSTAT 1
#define EXPBAROSTAT 2
#define THERMOSTATAND 1
#define THERMOSTATNHC 2

#define RANDOM_INIT_COORD 1
#define TRAJECTORY_COORD 2
#define NODE_NUM 5
