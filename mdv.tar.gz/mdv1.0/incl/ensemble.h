#pragma once
#include "define.h"
#include "file.h"

//-------- The RDF object --------
typedef struct RDF_ {
	int divide_num;
	double delta_r;
	double rmax;
	long* histogram;
} RDF;

int init_rdf(RDF* rdf, int divide_num, double rmax);

int free_rdf(RDF* rdf);

int printf_rdf(RDF* rdf, FileList* fl);

//-------- End of The RDF object --------

//-------- The ensemble object --------
// Use init_ensembles, init_ensembles_const, free_ensembles
// need the follow code to init:
//	if ((ense = (Ensemble*)malloc(1 * sizeof(Ensemble))) == NULL)
//	{
//		perror("malloc_Ensemble");
//		system("pause");exit(EXIT_FAILURE);
//	}

typedef struct Ensemble_ {
	// the max space dim is 3
	// incoming values
	double temp0, energy0, volume0;
	double press0[DIM][DIM];
	int* num0; // # of diff particles
	double* chem_pot0;
	int particle_num; // the number of the species
	// instant values;
	double temp, energy, volume;
	double press[DIM][DIM];
	int* num;
	double* chem_pot;
	//double box[3]; // orthorhombic crystal system
	double h[DIM][DIM]; // triclinic crystal system, diag is the box[3]
	double beta;
	// propagator information
	double mv2;
	double virial;
	double total_mass;
	RDF rdf;
	bool rdf_switch;
} Ensemble;

int init_ensembles(Ensemble* ense, int num_ensembles, int* particle_num);

int init_ensembles_const(Ensemble* ense, int num_ensembles, int particle_num);

int init_ense_conditon(Ensemble* ense, Input* inp);

int free_ensembles(Ensemble* ense, int num_ensemble);

//-------- End of The ensemble object --------
