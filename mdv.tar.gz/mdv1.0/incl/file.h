#pragma once
#include "define.h"

//-------- The file object --------

typedef struct FileList_ {
	FILE* input_fp;
	FILE* temp_fp;
	FILE* energy_fp;
	FILE* log_fp;
	FILE* output_fp;
	FILE* press_fp;
	FILE* traj_fp;
	FILE* volume_fp;
	FILE* density_fp;
	FILE* rdf_fp;
	FILE* coordx_fp;
	FILE* coordp_fp;
} FileList;

void fopen_n(FILE** fpp, char* filename, char* type, char* error);

int init_file(FileList* fl);

int fclose_file(FileList* fl);

//-------- End of The file object --------

//-------- The input file object --------

typedef struct Input_ {
	int particle_num[FILE_SUB_TERM];
	int species_num;
	double temp, energy, volume;
	double h[3][3], press[3][3];
	double truncate_r;
	int method;
	// method: 1 -- Monte Carlo method
	//         2 -- Molecular dynamic method
	int ensemble;
	// ensemble: 1 -- NVE
	//           2 -- NVT
	//           3 -- NPT
	int particle_atom_num;
	int nhc_length;
	double nhc_tau;
	double baro_tau;
	double time;
	double deltaT;
	int trajectory;
	int mc_step;
	int barostat;
	double baro_scal_v;
	int thermostat;
	bool test_rdf;
	double mc_xscal;
	double mc_pscal;
	bool coord_xp_output;
	bool mc_steplength_change;
	int nhc_respa_num;
} Input;

int read_input_file(Input* input, FILE* fp);

//-------- End of The input file object --------