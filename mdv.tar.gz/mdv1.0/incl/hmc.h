#pragma once
#include "particle.h"
#include "ensemble.h"
#include "info.h"
#include "file.h"
#include "mc.h"
#include "md.h"
#include "pot.h"
#include "verlet.h"

//-------- The Hybrid MC method --------

typedef struct HMCInfo_ {
	MDInfo mdi;
	MCInfo mci;
} HMCInfo;

typedef struct HMCFun_ {
	MCFun mcf;
	MDFun mdf;
} HMCFun;

int init_hmc(HMCInfo* hmci, HMCFun* hmcf, Input* inp, Ensemble* ense, ParticleList* pl, NHChain* nhc, NHChain* nhc_baro, Barostat* baro);

void hmc_step(HMCInfo* hmci, HMCFun* hmcf, ParticleList* pl, ParticleList* pl_tmp, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);
