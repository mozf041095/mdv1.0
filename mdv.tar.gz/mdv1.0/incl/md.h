#pragma once
#include "ensemble.h"
#include "file.h"
#include "particle.h"
#include "pot.h"
#include "verlet.h"
#include "mc.h"


//-------- The Nose - Hoover chain object --------
typedef struct NHChain_ {
	int num; // the particle or virtual particle on which the nhc work
	int num_1;
	int chain_length;
	double* eta;
	double* peta;
	double* Q;
	double* G;
} NHChain;

int init_nhc(NHChain* nhc, Ensemble* ense, int aim_dim, int total_num, int chain_length, double tau);

int free_nhc(NHChain* nhc);


//-------- End of The Nose - Hoover chain object --------

//-------- The Molecular Dynamic object --------

typedef struct MDInfo_ {
	int md_step_num;
	int md_info_num;
	double delta_t;
	double sy_omega[7];
	int sy_num, sy_respa_num;
	double alpha;
	double anderson_nu;
	double nu_dt;
	Barostat baro;
	bool nhc_sw, nhc_baro_sw;
	long step;
} MDInfo;

typedef struct MDFun_ {
	void (*propagator)(MDInfo*, ParticleList*, Ensemble*, Barostat*, VerletList*, LJPotential, NHChain, NHChain);
} MDFun;


int init_md(MDInfo* mdi, MDFun* mdf, Input* inp, Ensemble* ense, ParticleList* pl, NHChain* nhc, NHChain* nhc_baro, Barostat* baro);

void propagator_nvt(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

void propagator_nvt_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

void propagator_nve(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

void propagator_npt(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

void propagator_npt_mcbarostat(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

void propagator_npt_mcbarostat_anderson(MDInfo* mdi, ParticleList* pl, Ensemble* ense, Barostat* baro, VerletList* vl, LJPotential lj, NHChain nhc, NHChain nhc_baro);

//-------- End of The Molecular Dynamic object --------