#pragma once

//-------- The basic unit object --------
typedef struct Unit_ {
	double ang1bohr;
	double bohrlang;
	double kb;
	double amunit;
	double fsltime;
	double timelfs;
	double hatree1eV;
	double eV1hatree;
	double rePlank;
	double Avogadro;
	double kPa1P;
	double P1kPa;
	double density1au;
} Unit;

Unit unit;

int init_unit();

//-------- End of The basic unit object --------

