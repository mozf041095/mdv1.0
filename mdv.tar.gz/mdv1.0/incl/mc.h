#pragma once
#include "file.h"
#include "ensemble.h"
#include "particle.h"
#include "verlet.h"
#include "pot.h"

//-------- The Monte Carlo object --------

typedef struct Barostat_ {
	double eps, peps, weps;
	double scalV;
	int mc_attempt_num, mc_accept_num;
} Barostat;

typedef struct MCInfo_ {
	// the control information of the Monte Carlo
	int mc_step_num;
	int mc_info_num;
	int mc_info_buff;
	double fac_x, fac_p;
	Barostat baro;
	int mc_attempt_num, mc_accept_num;
	bool steplength_change;
	double demon;
} MCInfo;


typedef struct MCFun_ {
	void (*mc_step)(MCInfo*, ParticleList*, VerletList*, Ensemble*, LJPotential);
} MCFun;

int init_mc(MCInfo* mci, MCFun* mcf, Input inputinfo);

void mc_barostat(ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj, Barostat* bs, int mark);

void mc_step_nvt(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj);

void mc_step_npt(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj);

void mc_step_nve(MCInfo* mci, ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj);

//-------- End of The Monte Carlo object --------