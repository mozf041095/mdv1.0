#pragma once
#include "particle.h"
#include "verlet.h"
#include "pot.h"

//-------- The info object --------

int particle_mv2(ParticleList* pl, Ensemble* ense);

int particle_ene(ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj);

int particle_virial(ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj);

int particle_info(ParticleList* pl, Ensemble* ense, VerletList* vl, int mark);

//-------- End of The info object --------