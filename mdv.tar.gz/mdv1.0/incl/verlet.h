#pragma once
#include "particle.h"

//-------- The Verlet List object --------

typedef struct VerletList_ {
	double radius;
	double radius2; // radius^2
	int* num;
	int* num_total; // verlet list size of every particles
	int numMax; // can change with the density
	unsigned int* x; // dim: nParticle * numMax * 2[ box index ]
} VerletList;

int init_verlet_list(VerletList* vl, ParticleList* pl);

int free_verlet_list(VerletList* vl);

int create_verlet_list_monatomic(VerletList* vl, ParticleList* pl, Ensemble* ense);

void distance(ParticleList* pl, VerletList* vl);

//-------- End of The Verlet List object --------

