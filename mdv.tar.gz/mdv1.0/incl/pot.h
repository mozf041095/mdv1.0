#pragma once
#include "particle.h"
#include "ensemble.h"
#include "verlet.h"

//-------- The LJ Potential object --------

typedef struct LJPotential_ {
	double sigma;
	double sigma_2; // sigma^2
	double epsilon;
	double m4_epsilon; // 4.0 * epsilon
} LJPotential;

int		init_lj(LJPotential* lj, int mark);

double	lj_pair_pot(double x1[], double x2[], LJPotential lj);

void	lj_pair_force(double x1[], double x2[], double* force, LJPotential lj);

double	lj_pot_monatomic_v(ParticleList* pl, VerletList* vl, Ensemble* ense, LJPotential lj);

double	lj_pot_monatomic_v_1p(ParticleList* pl, int* vl_x, int num, Particle* par, LJPotential lj, Ensemble* ense);

double	lj_pot_monatomic_p(ParticleList* pl, LJPotential lj);

double	lj_pot_monatomic_p_1p(ParticleList* pl, Particle* par, LJPotential lj, int par_index);

//-------- End of The LJ Potential object --------