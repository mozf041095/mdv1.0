#pragma once
#include "define.h"


//-------- The random object --------

void init_rand();

double rand_d1();

double rand_std();

double rand_gauss();

//-------- End of The random object --------



//-------- The cmd control object --------
#ifdef WIN_CONDITION
void full_screen();

#endif // !WIN_CODITION
//-------- End of The cmd control object --------

//-------- The math lib --------
double triproduct(double* x);

//-------- End of The math lib --------


int box_index(int line_index, int dim);