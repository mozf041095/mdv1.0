#!/bin/bash

for i in $@
do
    mkdir $i
    cp input* mcmd.exe ./$i/
    cd $i
    time ./mcmd.exe 1> log.txt 2>error.txt &
    cd ../
done
