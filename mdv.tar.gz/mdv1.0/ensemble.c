#include "define.h"
#include "file.h"
#include "unit.h"
#include "ensemble.h"

int init_ensemble(Ensemble* ense);

int free_ensemble(Ensemble* ense);

//-------- The ensemble object --------
int init_ensemble(Ensemble* ense)
{
	int i, j;

	for (i = 0; i < DIM; i++)
		for (j = 0; j < DIM; j++)
		{
			ense->press0[i][j] = 0.0;
			ense->press[i][j] = 0.0;
			ense->h[i][j] = 0.0;
		}

	if ((ense->num0 = (int*)malloc(ense->particle_num * sizeof(int))) == NULL)
	{
		perror("malloc_Ensemble_num0");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((ense->num = (int*)malloc(ense->particle_num * sizeof(int))) == NULL)
	{
		perror("malloc_Ensemble_num");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((ense->chem_pot0 = (double*)malloc(ense->particle_num * sizeof(double))) == NULL)
	{
		perror("malloc_Ensemble_chem_pot0");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	if ((ense->chem_pot = (double*)malloc(ense->particle_num * sizeof(double))) == NULL)
	{
		perror("malloc_Ensemble_chem_pot");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
		system("pause");
#else
		getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
		exit(EXIT_FAILURE);
	}
	return 0;
}

int init_ensembles(Ensemble* ense, int num_ensembles, int* particle_num)
{
	int i;
	printf(" Init the Ensemble ... \n");
	for (i = 0; i < num_ensembles; i++)
	{
		(ense + i)->particle_num = *(particle_num + i);
		init_ensemble((ense + i));
	}
	return 0;
}

int init_ensembles_const(Ensemble* ense, int num_ensembles, int particle_num)
{
	int i;
	printf(" Init the Ensemble ... \n");
	for (i = 0; i < num_ensembles; i++)
	{
		(ense + i)->particle_num = particle_num;
		init_ensemble((ense + i));
	}
	return 0;
}

int init_ense_conditon(Ensemble* ense, Input* inp)
{
	int i, j;

	ense->temp0 = inp->temp;
	ense->beta = 1.0 / (unit.kb * inp->temp);
	ense->energy0 = inp->energy * unit.hatree1eV;
	ense->volume0 = inp->volume * pow(unit.bohrlang, 3.0);
	ense->rdf_switch = inp->test_rdf;
	for (i = 0; i < DIM; i++)
		for (j = 0; j < DIM; j++)
		{
			ense->press0[i][j] = inp->press[i][j] * unit.P1kPa;
			//printf(" -- %f -- \n", ense->press0[i][j]);
			ense->h[i][j] = inp->h[i][j] * unit.bohrlang;
		}
	return 0;
}

int free_ensemble(Ensemble* ense)
{
	free(ense->num0);
	free(ense->num);
	free(ense->chem_pot0);
	free(ense->chem_pot);
	return 0;
}

int free_ensembles(Ensemble* ense, int num_ensemble)
{
	int i;
	printf(" Free the memory of Ensemble ...\n");
	for (i = 0; i < num_ensemble; i++)
	{
		free_ensemble(ense + i);
	}
	free(ense);
	return 0;
}

//-------- End of The ensemble object --------

//-------- The RDF object --------

int init_rdf(RDF* rdf, int divide_num, double rmax)
{
	int i;
	rdf->divide_num = divide_num;
	rdf->rmax = rmax;
	rdf->delta_r = rmax / (double)divide_num;
	//printf("%d, %f, %f\n", rdf->divide_num, rdf->rmax, rdf->delta_r);
	if (rdf->divide_num > 1)
	{
		if ((rdf->histogram = (long*)malloc((rdf->divide_num + 1) * sizeof(long))) == NULL) // boundary
		{
			perror("malloc_rdf_histogram");
#ifdef UNBACKGROUND
#ifdef WIN_CONDITION
			system("pause");
#else
			getchar();
#endif // WIN_CONDITION
#endif // UNBACKGROUND
			exit(EXIT_FAILURE);
		}
		for (i = 0; i <= rdf->divide_num; i++)
			rdf->histogram[i] = 0;
	}
	else
	{
		printf(" Error: rdf divide number must be larger than 1\n");
		return -1;
	}
	return 0;
}

int free_rdf(RDF* rdf)
{
	free(rdf->histogram);
	return 0;
}

int printf_rdf(RDF* rdf, FileList* fl)
{
	int i;
	fopen_n(&fl->rdf_fp, "rdf.dat", "w", "fopen_rdf");
	for (i = 0; i < rdf->divide_num; i++)
	{
		//printf(" -- %d \n", rdf->histogram[i]);
		fprintf(fl->rdf_fp, "%-30.10f %15d\n", rdf->delta_r * (double)i, rdf->histogram[i]);
	}
	fclose(fl->rdf_fp);
}
//-------- End of The RDF object --------

