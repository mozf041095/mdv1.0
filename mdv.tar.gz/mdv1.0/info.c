#include "define.h"
#include "info.h"
#include "pot.h"
#include "unit.h"
#include "lib.h"

//-------- The info object --------

int particle_mv2(ParticleList* pl, Ensemble* ense)
{
	int i, j, k;
	double mv2;
	mv2 = 0;
	for (i = 0; i < pl->num; i++)
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				mv2 += pow((pl->list + i)->p[j * DIM + k], 2.0) / (pl->list + i)->mass[j];
				//fprintf( debugfp,  "mv2: %d %d %d -- %f  %f\n", i, j, k, (pl->list + i)->p[j * DIM + k], (pl->list + i)->mass[j]);
			}
		}
	ense->mv2 = mv2;
	return 0;
}

int particle_ene(ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj)
{
	particle_mv2(pl, ense);
#ifdef VERLET_USE
	ense->energy = 0.5 * ense->mv2 + lj_pot_monatomic_v(pl, vl, ense, lj);
#else
	ense->energy = 0.5 * ense->mv2 + lj_pot_monatomic_p(pl, lj);
#endif // VERLET_USE
	//printf("%f   %f   \n", ense->mv2, ense->energy);
}

int particle_virial(ParticleList* pl, Ensemble* ense, VerletList* vl, LJPotential lj)
{
	int i, j, k;
	double x[3], force[3];
	double virial;
	virial = 0;
	for (i = 0; i < pl->num; i++)
	{
		//fprintf( debugfp, " -- %d\n", pl->num);
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			//fprintf( debugfp, " -- %d\n", *(vl->num + i) * 2);
			//fprintf( debugfp, "%d, %f -- %d, %f\n", i, (pl->list + i)->x[0], *(vl->x + i * vl->numMax * 2 + j), (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[0]);
			for (k = 0; k < DIM; k++)
			{
				x[k] = (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k];
			}
			lj_pair_force((pl->list + i)->x, x, force, lj);
#ifdef DEBUG_

			if (abs(force[0]) > 0.01)
			{
				fprintf(debugfp, " %d %d -- %f, %f, %f || %f, %f, %f, ***** %30.20f, %30.20f, %30.20f\n", i, *(vl->x + i * vl->numMax * 2 + j),\
					x[0], x[1], x[2], (pl->list + i)->x[0], (pl->list + i)->x[1], (pl->list + i)->x[2], force[0], force[1], force[2]);
			}
#endif // DEBUG_
			for (k = 0; k < DIM; k++)
			{
				virial += ((pl->list + i)->x[k] - x[k]) * force[k];
			}
		}
	}
	ense->virial = virial;
	return 0;
}

int particle_info(ParticleList* pl, Ensemble* ense, VerletList* vl, int mark)
{
	int i, j, k, ndof;
	double mv2;
	double virial;
	double force[3] = { 0, 0, 0 };
	double x[3] = { 0, 0, 0 };
	double r;
	double pot;
	LJPotential lj;
	init_lj(&lj, HeLJ);
	mv2 = 0;
	virial = 0;
	ndof = 0;
	for (i = 0; i < pl->num; i++)
		for (j = 0; j < (pl->list + i)->subnum; j++)
		{
			for (k = 0; k < DIM; k++)
			{
				mv2 += pow((pl->list + i)->p[j * DIM + k], 2.0) / (pl->list + i)->mass[j];

				ndof++;
				//fprintf( debugfp,  "info_mv2:%d %d %d -- %f  %f\n", i, j, k, (pl->list + i)->p[j * DIM + k], (pl->list + i)->mass[j]);
			}
		}

	for (i = 0; i < pl->num; i++)
	{
		//fprintf( debugfp, " -- %d\n", pl->num);
		for (j = 0; j < *(vl->num + i) * 2; j += 2)
		{
			//fprintf( debugfp, " -- %d\n", *(vl->num + i) * 2);
			//fprintf( debugfp, "%d, %f -- %d, %f\n", i, (pl->list + i)->x[0], *(vl->x + i * vl->numMax * 2 + j), (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[0]);
			for (k = 0; k < DIM; k++)
			{
				x[k] = (pl->list + *(vl->x + i * vl->numMax * 2 + j))->x[k] + box_index(*(vl->x + i * vl->numMax * 2 + j + 1), k) * ense->h[k][k];
			}
			lj_pair_force((pl->list + i)->x, x, force, lj);
			//fprintf( debugfp, " -- %f, %f, %f ***** %30.20f, %30.20f, %30.20f\n", x[0], x[1], x[2], force[0], force[1], force[2]);
			for (k = 0; k < DIM; k++)
			{
				virial += ((pl->list + i)->x[k] - x[k]) * force[k];
			}
		}
	}

#ifdef VERLET_USE
	pot = lj_pot_monatomic_v(pl, vl, ense, lj);
#else
	pot = lj_pot_monatomic_p(pl, lj);
#endif // VERLET_USE

#ifdef DEBUG_
	//fprintf(debugfp, "\nfinal: mv2 -- %f; virial -- %30.20f; pot -- %30.20f\n", mv2, virial, pot);
#endif // DEBUG_

	// propagator information
	ense->mv2 = mv2;
	ense->virial = virial;
	ense->temp = mv2 / ((double)ndof * unit.kb);
	ense->energy = 0.5 * mv2 + pot;
	for(i = 0; i < DIM; i++)
		ense->press[i][i] = (mv2 + virial) / (3.0 * triproduct(ense->h[0]));
	//fprintf( debugfp, "%f, %f, %f, %f\n", ense->h[0][0], ense->h[1][1], ense->h[2][2], triproduct(ense->h));

	return 0;
}




//-------- End of The info object -------- 